/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.bluetooth;

import java.lang.StringBuffer;

/**
 * Represents a trusted bluetooth device.
 *
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 * @mib.state DOCUMENTED
 *
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public class TrustedDevice {
	/**
	 * The user friendly name of the trusted Bluetooth device.<br>
	 * Value Range: String
	 */
	public String deviceName;

	/**
	 * The Bluetooth device address represented in hex format.<br>
	 * Value Range: String
	 */
	public String deviceAddress;

	/**
	 * The 32bit Bluetooth device class describes the type of device.<br>
	 * The definition of the single bits is according to the Bluetooth core
	 * protocol (Assigned Numbers).<br>
	 * Value Range: int
	 */
	public int deviceClass;

	/**
	 * The 32Bitfield describes whether the Bluetooth device is trusted, paired
	 * or unknown.<br>
	 * Value Range: Bitfield DeviceSecurity (see
	 * {@link DSIBluetooth#DEVICESECURITY_TRUSTED} ff.)
	 */
	public int deviceSecurity;

	/**
	 * Describes the link state of the Bluetooth device.<br>
	 * Value Range: Enumeration LinkMode (see
	 * {@link DSIBluetooth#LINKMODE_UNSPECIFIED} ff.)
	 */
	public int linkMode;

	/**
	 * Link key strength of the trusted device.<br>
	 * Value Range: Enumeration LS (see {@link DSIBluetooth#LS_UNDEFINED} ff.)
	 */
	public int linkkeyStrength;

	/**
	 * Integer indicating the services, that were connected the last time the
	 * device was paired.<br>
	 * Value range: Bitfield ServiceType <br>
	 * (see {@link DSIBluetooth#SERVICETYPE_NONE} ff.)
	 */
	public int lastConnectedServiceTypes;

	/**
	 * the high level services currently connected <br>
	 * Value range: Bitfield ServiceType <br>
	 * (see {@link DSIBluetooth#SERVICETYPE_NONE} ff.)
	 */
	public int activeServiceTypes;

	/**
	 * the high level services offered by the Bluetooth device<br>
	 * Value range: Bitfield ServiceType <br>
	 * (see {@link DSIBluetooth#SERVICETYPE_NONE} ff.)
	 */
	public int offeredServiceTypes;

	/**
	 * Default constructor without parameters.
	 */
	public TrustedDevice() {
		this.deviceName = null;
		this.deviceAddress = null;
		this.deviceClass = 0;
		this.deviceSecurity = 0;
		this.linkMode = 0;
		this.linkkeyStrength = 0;
		this.lastConnectedServiceTypes = 0;
		this.activeServiceTypes = 0;
		this.offeredServiceTypes = 0;
	}

	/**
	 * @param deviceName
	 * @param deviceAddress
	 * @param deviceClass
	 * @param deviceSecurity
	 * @param linkMode
	 * @param linkkeyStrength
	 * @param lastConnectedServiceTypes
	 * @param activeServiceTypes
	 * @param offeredServiceTypes
	 */
	public TrustedDevice(String deviceName, String deviceAddress,
			int deviceClass, int deviceSecurity, int linkMode,
			int linkkeyStrength, int lastConnectedServiceTypes,
			int activeServiceTypes, int offeredServiceTypes) {
		this.deviceName = deviceName;
		this.deviceAddress = deviceAddress;
		this.deviceClass = deviceClass;
		this.deviceSecurity = deviceSecurity;
		this.linkMode = linkMode;
		this.linkkeyStrength = linkkeyStrength;
		this.lastConnectedServiceTypes = lastConnectedServiceTypes;
		this.activeServiceTypes = activeServiceTypes;
		this.offeredServiceTypes = offeredServiceTypes;
	}

	/**
	 * @return the deviceName
	 */
	public String getDeviceName() {
		return deviceName;
	}

	/**
	 * @return the deviceAddress
	 */
	public String getDeviceAddress() {
		return deviceAddress;
	}

	/**
	 * @return the deviceClass
	 */
	public int getDeviceClass() {
		return deviceClass;
	}

	/**
	 * @return the deviceSecurity
	 */
	public int getDeviceSecurity() {
		return deviceSecurity;
	}

	/**
	 * @return the linkMode
	 */
	public int getLinkMode() {
		return linkMode;
	}

	/**
	 * @return the linkkeyStrength
	 */
	public int getLinkkeyStrength() {
		return linkkeyStrength;
	}

	/**
	 * @return the lastConnectedServiceTypes
	 */
	public int getLastConnectedServiceTypes() {
		return lastConnectedServiceTypes;
	}

	/**
	 * @return the activeServiceTypes
	 */
	public int getActiveServiceTypes() {
		return activeServiceTypes;
	}

	/**
	 * @return the offeredServiceTypes
	 */
	public int getOfferedServiceTypes() {
		return offeredServiceTypes;
	}

	/**
	 * Convert data type to string for debugging purposes.
	 * @return {@link String} representation of this object with simple value output
	 */
	public String toString() {
		final StringBuffer buffer = new StringBuffer(650);
		buffer.append("TrustedDevice");
		buffer.append('(');
		buffer.append("deviceName");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.deviceName);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("deviceAddress");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.deviceAddress);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("deviceClass");
		buffer.append('=');
		buffer.append(this.deviceClass);
		buffer.append(',');
		buffer.append("deviceSecurity");
		buffer.append('=');
		buffer.append(this.deviceSecurity);
		buffer.append(',');
		buffer.append("linkMode");
		buffer.append('=');
		buffer.append(this.linkMode);
		buffer.append(',');
		buffer.append("linkkeyStrength");
		buffer.append('=');
		buffer.append(this.linkkeyStrength);
		buffer.append(',');
		buffer.append("lastConnectedServiceTypes");
		buffer.append('=');
		buffer.append(this.lastConnectedServiceTypes);
		buffer.append(',');
		buffer.append("activeServiceTypes");
		buffer.append('=');
		buffer.append(this.activeServiceTypes);
		buffer.append(',');
		buffer.append("offeredServiceTypes");
		buffer.append('=');
		buffer.append(this.offeredServiceTypes);
		buffer.append(')');
		return buffer.toString();
	}

}
