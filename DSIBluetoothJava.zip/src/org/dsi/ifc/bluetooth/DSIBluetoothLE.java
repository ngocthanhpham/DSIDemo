/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */

package org.dsi.ifc.bluetooth;

import org.dsi.ifc.base.DSIBase;

/**
 * Device Service interface definition for Bluetooth LowEnergy.
 * <p>
 * This DSI service provides functionality for sending requests to and
 * retrieving information from the bluetooth application.<br>
 * Notes:
 * <p>
 * Bluetooth LowEnergy device addresses are always represented by their MAC
 * addresses in hex format (e.g. 01:02:03:04:05).<br>
 * Bluetooth LowEnergy device name is always the user friendly name of the
 * device. A <code>null</code> string means that the name is unspecified. Max.
 * 248 characters, UTF-8 encoding.
 *
 * @servicename BluetoothLE
 * @version specification version of DSI service (1.0.0)
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public interface DSIBluetoothLE extends DSIBase {

	/**
	 * Version of DSI service 'org.dsi.ifc.bluetooth'.
	 */
	public static final String VERSION = "2.12.18";
	/**************************************************/
	/******************** Updates *********************/
	/**************************************************/

	public static final int ATTR_ACCESSIBLEMODE = 1;
	public static final int ATTR_BTSTATE = 2;
	public static final int ATTR_SERVICE = 3;
	public static final int ATTR_TRUSTEDDEVICES = 4;
	public static final int ATTR_PASSKEYSTATE = 5;
	public static final int ATTR_USERFRIENDLYNAME = 6;
	public static final int ATTR_CHARACTERISTICVALUE = 7;

	/**************************************************/
	/******************** Requests ********************/
	/**************************************************/

	public static final int RT_REQUESTPASSKEYRESPONSE = 1001;
	public static final int RT_REQUESTREMOVEAUTHENTICATION = 1002;
	public static final int RT_REQUESTSETUSERFRIENDLYNAME = 1003;
	public static final int RT_REQUESTSWITCHBTSTATE = 1004;
	public static final int RT_REQUESTSETSERVICE = 1005;
	public static final int RT_SETACCESSIBLEMODE = 1006;
	public static final int RT_REQUESTSETCHARACTERISTICSTATE = 1007;
	public static final int RT_REQUESTNOTIFYCHARACTERISTICVALUE = 1008;

	/**************************************************/
	/******************** Responses *******************/
	/**************************************************/

	public static final int RP_RESPONSEPASSKEYRESPONSE = 2001;
	public static final int RP_RESPONSEREMOVEAUTHENTICATION = 2002;
	public static final int RP_RESPONSESWITCHBTSTATE = 2003;
	public static final int RP_RESPONSESETSERVICE = 2004;
	public static final int RP_RESPONSESETACCESSIBLEMODE = 2005;
	public static final int RP_RESPONSESETCHARACTERISTICSTATE = 2006;
	public static final int RP_RESPONSENOTIFYCHARACTERISTICVALUE = 2007;

	/**************************************************/
	/******************* Indications ******************/
	/**************************************************/
	public static final int IN_DEVICEDISCONNECTIONINFO = 3001;

	/**************************************************/
	/******************** Request *********************/
	/**************************************************/

	/**
	 * This method is used to send a bluetooth passkey.
	 * <p>
	 * This key is used for pairing with a specific bluetooth le device. The
	 * indication whether the passkey is to be displayed or has to be entered is
	 * done by the <i>updatePasskeyState</i> attribute.<br>
	 *
	 * This method is be used to accept or reject a requested authentication. If
	 * the authentication is rejected, the passkey shall be ignored.
	 *
	 * @param btPasskey
	 *            the bluetooth passkey<br>
	 *            Value Range: {@link String}, max. 16 characters TODO
	 *            Unicode/US ASCII/numbers?
	 * @param btDeviceAddress
	 *            the Bluetooth device address represented in hex format.<br>
	 *            Value Range: {@link String}
	 * @param btAuthenticationResponse
	 *            indicates whether to reject or accept authentication.<br>
	 *            Value Range: Enumeration Authentication (see
	 *            {@link Constants#AUTHENTICATION_REJECT} f.)
	 *
	 * @type Request
	 *
	 * @response {@link DSIBluetoothLEListener#responsePasskeyResponse(String, String, int)}
	 *
	 * @relatedfunc {@link DSIBluetoothLEListener#updatePasskeyState(PasskeyStateStruct, int)}
	 *
	 * @requirement
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 *
	 * @prj.vw-hmi.request-timeout 180000
	 */
	public void requestPasskeyResponse(String btPasskey,
			String btDeviceAddress, int btAuthenticationResponse);

	/**
	 * With this request the user is able to remove a bluetooth device from the
	 * list of trusted devices.<br>
	 * In case the Bluetooth device address equals a NULL string, all trusted
	 * Bluetooth-user-devices shall be deleted, but not the Bluetooth system
	 * components like BTHSs or BT-headphones of the Rear-Seat-Entertainment.<br>
	 * Removing a device from the list of trusted devices implies the deletion
	 * of the according link key.
	 * <p>
	 *
	 * @param btDeviceAddress
	 *            the Bluetooth device address (represented in hex format) of
	 *            the bluetooth device for which the authentication is to be
	 *            removed.<br>
	 *            In case the btDeviceAddress equals a NULL string, all trusted
	 *            Bluetooth-user-devices shall be deleted, but not the Bluetooth
	 *            system components like BTHSs or BT-headphones of the
	 *            Rear-Seat-Entertainment.<br>
	 *            .<br>
	 *            Value Range: {@link String}
	 *
	 * @type Request
	 *
	 * @response {@link DSIBluetoothLEListener#responseRemoveAuthentication(String, String, int)}
	 *
	 * @relatedfunc {@link DSIBluetoothLEListener#updateTrustedDevices(TrustedLEDevice[], int)}
	 *
	 * @requirement
	 *
	 * @pre no precondition
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 *
	 * @prj.vw-hmi.request-timeout 180000
	 */
	public void requestRemoveAuthentication(String btDeviceAddress);

	/**
	 * With this request the user is able to switch the state of the local
	 * bluetooth device.<br>
	 * If the requested setting is already active, it shall be left as it is and
	 * {@link DSIBluetoothLEListener#responseSwitchBTState(int)} shall return
	 * with {@link Constants#RESULT_OK}.
	 *
	 * @param btStateTarget
	 *            the new target state.<br>
	 *            Value Range: Enumeration BTState (see
	 *            {@link Constants#BTSTATE_ON} ff.)
	 *            <ul>
	 *            <li>{@link Constants#BTSTATE_ON}: switch on (and persist
	 *            state)</li>
	 *            <li>{@link Constants#BTSTATE_OFF}: switch off (and persist
	 *            state)</li>
	 *            </ul>
	 *
	 * @type Request
	 *
	 * @response {@link DSIBluetoothLEListener#responseSwitchBTState(int)}
	 *
	 * @relatedfunc {@link DSIBluetoothLEListener#updateBTState(int, int)}
	 *
	 * @requirement
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 *
	 *
	 * @prj.vw-hmi.request-timeout 60000
	 */
	public void requestSwitchBTState(int btStateTarget);

	/**
	 * With this request the user is able to switch the accessible mode of the
	 * local bluetooth device.
	 * <p>
	 * If the attribute has changed, an update will be called (single parameter
	 * update, see {@link DSIBluetoothLEListener#updateAccessibleMode(int, int)}
	 * ).
	 *
	 * @param accessibleMode
	 *            the accessible mode of the bluetooth device.<br>
	 *            Value Range: Enumeration AM (see
	 *            {@link Constants#AM_UNSPECIFIED} ff.)
	 *
	 * @type Request
	 *
	 * @response {@link DSIBluetoothLEListener#responseSetAccessibleMode(int)}
	 *
	 * @relatedfunc {@link DSIBluetoothLEListener#updateAccessibleMode(int, int)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void setAccessibleMode(int accessibleMode);

	/**
	 * With this request the user is able to set the user friendly name of the
	 * local bluetooth device.<br>
	 *
	 * This request causes an attribute change. If the attribute has changed, an
	 * update will be called (single parameter update:
	 * {@link DSIBluetoothLEListener#updateUserFriendlyName(String, int)}).
	 *
	 * @param userFriendlyName
	 *            the name the user friendly name of the local bluetooth device
	 *            is to be set to..<br>
	 *            Value Range: {@link String}
	 *
	 * @type Request
	 *
	 * @response none
	 *
	 * @relatedfunc {@link DSIBluetoothLEListener#updateUserFriendlyName(String, int)}
	 *
	 * @requirement
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void requestSetUserFriendlyName(String Name);

	/**
	 * With this request the user is able to switch the state of a bluetooth le
	 * profile.<br>
	 * If the requested setting is already active, it shall be left as it is and
	 * {@link DSIBluetoothLEListener#responseSetService(int)} shall return with
	 * {@link Constants#RESULT_OK}.
	 *
	 * @param ServiceID
	 *            the new target state.<br>
	 *            Value Range: Bitfields ServiceID (see
	 *            {@link Constants#SERVICEID_DIS} ff.)
	 *
	 * @param ServiceState
	 *            the new target state.<br>
	 *            Value Range: Enumeration ServiceState (see
	 *            {@link Constants#SERVICESTATE_OFF} ff.)
	 *            <ul>
	 *            <li>{@link Constants#SERVICESTATE_OFF}: switch off (and
	 *            persist state)</li>
	 *            <li>{@link Constants#SERVCIESTATE_TEMPORALLY_DISABLED}:
	 *            temporally disabled (and persist state)</li>
	 *            <li>{@link Constants#SERVICESTATE_ALL}: all devices (and
	 *            persist state)</li>
	 *            <li>{@link Constants#SERVICESTATE_TRUSTED}: only trusted (and
	 *            persist state)</li>
	 *            <li>{@link Constants#SERVICESTATE_CRYPTED}: only crypted (and
	 *            persist state)</li>
	 *            <li>{@link Constants#SERVICESTATE_TRUSTED_CRYPTED}: only
	 *            trusted and crypted (and persist state)</li>
	 *            </ul>
	 *
	 * @type Request
	 *
	 * @response {@link DSIBluetoothLEListener#responseSetService(int)}
	 *
	 * @relatedfunc {@link DSIBluetoothLEListener#updateService(BleService, int)}
	 *
	 * @requirement
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 *
	 *
	 * @prj.vw-hmi.request-timeout 60000
	 */
	public void requestSetService(int ServiceID, int ServiceState);

	/**
	 * With this request the user is able to switch the state of a bluetooth le
	 * characteristic.<br>
	 * If the requested setting is already active, it shall be left as it is and
	 * {@link DSIBluetoothLEListener#responseSetCharacteristicState(int)} shall
	 * return with {@link Constants#RESULT_OK}.
	 *
	 * @param uuid
	 *            the 128-bit UUID of the Service Characteristic
	 *
	 * @param serviceState
	 *            the new target state.<br>
	 *            Value Range: Enumeration ServiceState (see
	 *            {@link Constants#SERVICESTATE_OFF} ff.)
	 *            <ul>
	 *            <li>{@link Constants#SERVICESTATE_OFF}: switch off (and
	 *            persist state)</li>
	 *            <li>{@link Constants#SERVCIESTATE_TEMPORALLY_DISABLED}:
	 *            temporally disabled (and persist state)</li>
	 *            <li>{@link Constants#SERVICESTATE_ALL}: all devices (and
	 *            persist state)</li>
	 *            <li>{@link Constants#SERVICESTATE_TRUSTED}: only trusted (and
	 *            persist state)</li>
	 *            <li>{@link Constants#SERVICESTATE_CRYPTED}: only crypted (and
	 *            persist state)</li>
	 *            <li>{@link Constants#SERVICESTATE_TRUSTED_CRYPTED}: only
	 *            trusted and crypted (and persist state)</li>
	 *            </ul>
	 *
	 * @type Request
	 *
	 * @response {@link DSIBluetoothLEListener#responseSetCharacteristicState(int)}
	 *
	 * @requirement
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 *
	 *
	 * @prj.vw-hmi.request-timeout 60000
	 */
	public void requestSetCharacteristicState(String uuid, int serviceState);

	/**
	 * With this request the user is able to set the notify value of a service
	 * characteristic.<br>
	 * If the requested setting is already active, it shall be left as it is and
	 * {@link DSIBluetoothLEListener#responseSetService(int)} shall return with
	 * {@link Constants#RESULT_OK}.
	 *
	 * @param characteristicUUID
	 *            the 128-bit UUID of the Service Characteristic<br>
	 *            Value Range: {@link String}
	 * @param notifyValue
	 *            the data to be notified to the Central device<br>
	 *            Value Range: {@link String}
	 *
	 * @type Request
	 *
	 * @response {@link DSIBluetoothLEListener#responseNotifyCharacteristicValue(int)}
	 *
	 * @relatedfunc {@link DSIBluetoothLEListener#updateCharacteristicValue(String, String, int)}
	 *
	 * @requirement
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 *
	 *
	 * @prj.vw-hmi.request-timeout 60000
	 */
	public void requestNotifyCharacteristicValue(String characteristicUUID,
			String notifyValue);

}
