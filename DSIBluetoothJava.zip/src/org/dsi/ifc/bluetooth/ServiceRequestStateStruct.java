/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */

package org.dsi.ifc.bluetooth;

import java.io.StringWriter;
import java.lang.StringBuffer;

/**
 * Represents a bluetooth service request state.
 *
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 * @mib.state APPROVED
 *
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public class ServiceRequestStateStruct {

	/**
	 * the state of the service request.<br>
	 * Value Range: Enumeration ServiceRequestState (see
	 * {@link DSIBluetooth#SERVICEREQUESTSTATE_NOT_ACTIVE} f.)
	 */
	public int btServiceRequestState;

	/**
	 * The Bluetooth device address represented in hex format.<br>
	 * Value Range: String
	 */
	public String btDeviceAddress;

	/**
	 * The user friendly name of the trusted Bluetooth device.<br>
	 * Value Range: String
	 */
	public String btDeviceName;

	/**
	 * Default constructor without parameters.
	 */
	public ServiceRequestStateStruct() {
		this.btServiceRequestState = 0;
		this.btDeviceAddress = null;
		this.btDeviceName = null;
	}

	/**
	 * Constructor with parameters.
	 */
	public ServiceRequestStateStruct(int btServiceRequestState,
			String btDeviceAddress, String btDeviceName) {
		this.btServiceRequestState = btServiceRequestState;
		this.btDeviceAddress = btDeviceAddress;
		this.btDeviceName = btDeviceName;
	}

	/**
	 * Getter : btServiceRequestState
	 *
	 * @return Returns the btServiceRequestState.
	 */
	public int getBtServiceRequestState() {
		return btServiceRequestState;
	}

	/**
	 * Getter : btDeviceAddress
	 *
	 * @return Returns the btDeviceAddress.
	 */
	public String getBtDeviceAddress() {
		return btDeviceAddress;
	}

	/**
	 * Getter : btDeviceName
	 *
	 * @return Returns the btDeviceName
	 */
	public String getBtDeviceName() {
		return btDeviceName;
	}

	/**
	 * Convert data type to string for debugging purposes.
	 * @return {@link String} representation of this object with simple value output
	 */
	public String toString() {
		final StringBuffer buffer = new StringBuffer(250);
		buffer.append("ServiceRequestStateStruct");
		buffer.append('(');
		buffer.append("btServiceRequestState");
		buffer.append('=');
		buffer.append(this.btServiceRequestState);
		buffer.append(',');
		buffer.append("btDeviceAddress");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btDeviceAddress);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("btDeviceName");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btDeviceName);
		buffer.append('\"');
		buffer.append(')');
		return buffer.toString();
	}

}
