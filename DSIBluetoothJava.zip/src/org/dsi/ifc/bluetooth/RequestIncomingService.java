/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */

package org.dsi.ifc.bluetooth;

import java.io.StringWriter;
import java.lang.StringBuffer;

/**
 * Represents an incoming service request from an external bluetooth device.
 *
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 * @mib.state APPROVED
 *
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public class RequestIncomingService {

	/**
	 * The user friendly name of the trusted Bluetooth device.<br>
	 * Value Range: String
	 */
	public String btDeviceName;

	/**
	 * The Bluetooth device address represented in hex format.<br>
	 * Value Range: String
	 */
	public String btDeviceAddress;

	/**
	 * the high-level service for the incoming service request. <br>
	 * There must only be one bit set.<br>
	 * Value range: Bitfield ServiceType, see
	 * {@link DSIBluetooth#SERVICETYPE_NONE} ff.
	 */
	public int btServiceType;

	/**
	 * Default constructor without parameters.
	 */
	public RequestIncomingService() {
		this.btDeviceName = null;
		this.btDeviceAddress = null;
		this.btServiceType = 0;
	}

	/**
	 * Constructor with parameters.
	 */
	public RequestIncomingService(String btDeviceName, String btDeviceAddress,
			int btServiceType) {
		this.btDeviceName = btDeviceName;
		this.btDeviceAddress = btDeviceAddress;
		this.btServiceType = btServiceType;
	}

	/**
	 * Getter : btDeviceName
	 *
	 * @return btDeviceName
	 */
	public String getBtDeviceName() {
		return btDeviceName;
	}

	/**
	 * Getter : btDeviceAddress
	 *
	 * @return btDeviceAddress
	 */
	public String getBtDeviceAddress() {
		return btDeviceAddress;
	}

	/**
	 * Getter : requestedService
	 *
	 * @return requestedService
	 */
	public int getBtServiceType() {
		return btServiceType;
	}

	/**
	 * Convert data type to string for debugging purposes.
	 * @return {@link String} representation of this object with simple value output
	 */
	public String toString() {
		final StringBuffer buffer = new StringBuffer(250);
		buffer.append("RequestIncomingService");
		buffer.append('(');
		buffer.append("btDeviceName");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btDeviceName);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("btDeviceAddress");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btDeviceAddress);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("btServiceType");
		buffer.append('=');
		buffer.append(this.btServiceType);
		buffer.append(')');
		return buffer.toString();
	}

}
