/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.bluetooth;

import java.lang.StringBuffer;

/**
 * Represents the reconnect information.<br>
 * This data type contains two list. On list (a Bitfield really) contains all
 * high level service types for which a reconnect procedure is active (
 * {@link #reconnectIndicator}).
 * <p>
 * And second a list of tuples of service type and device info that indicates
 * for each service type which device is either currently being tried to
 * reconnect to or is next on the list of devices to be reconnected to.
 * <p>
 * Thus it is possible to display the next A2DP device on an HMI media view and
 * the next HFP/SAP device on an HMI phone view in the reconnect phase.
 *
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 * @mib.state APPROVED
 *
 *
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public class ReconnectInfo {

	/**
	 * Indicates the high level service types for which a reconnect procedure is
	 * active.<br>
	 * Value range: Bitfield ServiceType<br>
	 * (see {@link DSIBluetooth#SERVICETYPE_NONE ff.})
	 */
	public int reconnectIndicator;

	/**
	 * Array containing the the corresponding Bluetooth device name for the
	 * services listed in {@link #serviceTypeList}. The name is either of the
	 * device for which there is a reconnect procedure active (i.e. the local
	 * Bluetooth is trying to connect to it at the moment) or the name of the
	 * Bluetooth device that is next on the list of devices to be reconnected
	 * for a certain high level service type.<br>
	 * Value Range: String[]
	 */
	public String[] deviceNameList;

	/**
	 * Array containing the individual service types for which a reconnect
	 * procedure is active.<br>
	 * Each service type may only occur <b>once</b> in the array. Must be in
	 * sync with {@link #deviceNameList}.<br>
	 * Value range: Bitfield ServiceType[]<br>
	 * (see {@link DSIBluetooth#SERVICETYPE_NONE ff.})
	 */
	public int[] serviceTypeList;

	/**
	 * Instantiates a new reconnect info.
	 */
	public ReconnectInfo() {
		this.reconnectIndicator = 0;
		this.deviceNameList = null;
		this.serviceTypeList = null;
	}

	/**
	 * @param reconnectIndicator
	 * @param deviceNameList
	 * @param serviceTypeList
	 */
	public ReconnectInfo(int reconnectIndicator, String[] deviceNameList,
			int[] serviceTypeList) {
		this.reconnectIndicator = reconnectIndicator;
		this.deviceNameList = deviceNameList;
		this.serviceTypeList = serviceTypeList;
	}

	/**
	 * @return Returns the reconnectIndicator.
	 */
	public int getReconnectIndicator() {
		return reconnectIndicator;
	}

	/**
	 * @return Returns the deviceNameList.
	 */
	public String[] getDeviceNameList() {
		return deviceNameList;
	}

	/**
	 * @return Returns the serviceTypeList.
	 */
	public int[] getServiceTypeList() {
		return serviceTypeList;
	}

	private String arrayToString(Object array, int len) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (int i = 0; i < len; i++) {
			if (i > 0) {
				buffer.append(", ");
			}
			if (array instanceof int[]) {
				buffer.append(((int[]) array)[i]);
			}
			if (array instanceof Object[]) {
				buffer.append(((Object[]) array)[i]);
			}
		}
		buffer.append("]");
		return buffer.toString();
	}

	/**
	 * Convert data type to string for debugging purposes.
	 * @return {@link String} representation of this object with simple value output
	 */
	public String toString() {
		final StringBuffer buffer = new StringBuffer(200);
		buffer.append("ReconnectInfo");
		buffer.append('(');
		buffer.append("reconnectIndicator");
		buffer.append('=');
		buffer.append(this.reconnectIndicator);
		buffer.append(',');
		{
			buffer.append("deviceNameList");
			buffer.append('[');
			if (this.deviceNameList != null) {
				buffer.append(this.deviceNameList.length);
			}
			buffer.append(']');
			buffer.append('=');
			buffer.append('{');
			if (this.deviceNameList != null) {
				final int len = this.deviceNameList.length;
				final int len2 = len - 1;
				for (int i = 0; i < len; i++) {
					buffer.append('\"');
					buffer.append(this.deviceNameList[i]);
					buffer.append('\"');
					if (i < len2)
						buffer.append(',');
				}
			} else {
				buffer.append(this.deviceNameList);
			}
			buffer.append('}');
		}
		buffer.append(',');
		{
			buffer.append("serviceTypeList");
			buffer.append('[');
			if (this.serviceTypeList != null) {
				buffer.append(this.serviceTypeList.length);
			}
			buffer.append(']');
			buffer.append('=');
			buffer.append('{');
			if (this.serviceTypeList != null) {
				final int len = this.serviceTypeList.length;
				final int len2 = len - 1;
				for (int i = 0; i < len; i++) {
					buffer.append(this.serviceTypeList[i]);
					if (i < len2)
						buffer.append(',');
				}
			} else {
				buffer.append(this.serviceTypeList);
			}
			buffer.append('}');
		}
		buffer.append(')');
		return buffer.toString();
	}

}
