/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */

package org.dsi.ifc.bluetooth;

import java.io.StringWriter;
import java.lang.StringBuffer;

/**
 * Represent a master role request.
 *
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 * @mib.state APPROVED
 *
 *
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public class MasterRoleRequestStruct {

	/**
	 * The Bluetooth address represented in Hex of the device requesting the
	 * master role.<br>
	 * Value Range: String
	 */
	public String btDeviceAddress;

	/**
	 * The Bluetooth name of the device requestinq the master role.<br>
	 * Value Range: String
	 */
	public String btDeviceName;

	/**
	 * This flag is set to true if the device has requested the Master role. It
	 * is reset immediately.<br>
	 * Value Range: boolean
	 */
	public boolean requested;

	/**
	 * Default constructor without parameters.
	 */
	public MasterRoleRequestStruct() {
		this.btDeviceAddress = null;
		this.btDeviceName = null;
		this.requested = false;
	}

	/**
	 * Constructor with parameters.
	 */
	public MasterRoleRequestStruct(String btDeviceAddress, String btDeviceName,
			boolean requested) {
		this.btDeviceAddress = btDeviceAddress;
		this.btDeviceName = btDeviceName;
		this.requested = requested;
	}

	/**
	 * Getter : The BT address of the device requestin the Master role
	 *
	 * @return The BT address of the device requestin the Master role
	 */
	public String getBtDeviceAddress() {
		return btDeviceAddress;
	}

	/**
	 * Getter : The BT name of the device requestin the Master role
	 *
	 * @return The BT name of the device requestin the Master role
	 */
	public String getBtDeviceName() {
		return btDeviceName;
	}

	/**
	 * Getter : This flag is set to true if the device has requested the Master
	 * role. It is reset immediately.
	 *
	 * @return This flag is set to true if the device has requested the Master
	 *         role. It is reset immediately.
	 */
	public boolean isRequested() {
		return requested;
	}

	/**
	 * Convert data type to string for debugging purposes.
	 * @return {@link String} representation of this object with simple value output
	 */
	public String toString() {
		final StringBuffer buffer = new StringBuffer(250);
		buffer.append("MasterRoleRequestStruct");
		buffer.append('(');
		buffer.append("btDeviceAddress");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btDeviceAddress);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("btDeviceName");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btDeviceName);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("requested");
		buffer.append('=');
		buffer.append(this.requested);
		buffer.append(')');
		return buffer.toString();
	}

}
