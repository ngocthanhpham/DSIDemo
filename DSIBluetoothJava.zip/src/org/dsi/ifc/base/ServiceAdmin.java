/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.base;

/**
 * This interface is used for the bootstrap of the DSI.
 * 
 * @mib.state APPROVED
 * @mib.common
 */
public interface ServiceAdmin {

	/**
	 * Starts the specified service asynchronous.
	 * <p>
	 * After successfully started, the service is available (registered) in the
	 * OSGi environment.
	 * </p>
	 * 
	 * @param service
	 *            The class name of the service provider.
	 * @param instance
	 *            The instance of the service
	 * @return Returns <code>true</code> and only <code>true</code>, if the
	 *         given arguments are valid and this trigger is successfully posted
	 *         to the underlying system/transport; <code>false</code> otherwise
	 */
	public boolean startService(String service, int instance);

	/**
	 * Stops the specified service asynchronous.
	 * <p>
	 * After successfully stopped, the service is no longer available
	 * (unregistered) in the OSGi environment.
	 * </p>
	 * 
	 * @param service
	 *            The class name of the service provider.
	 * @param instance
	 *            The instance of the service
	 * @return Returns <code>true</code> and only <code>true</code>, if the
	 *         given arguments are valid and this trigger is successfully posted
	 *         to the underlying system/transport; <code>false</code> otherwise
	 */
	public boolean stopService(String service, int instance);

}
