/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.base;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * This excpetion is used for handling exceptions that occur in the transport
 * layer below the DSI layer itself.
 * 
 * @servicename Base
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 * 
 * @mib.state APPROVED
 * @mib.common
 */
public class DSIException extends RuntimeException {

	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = -7777198285166341255L;

	/**
	 * Stores a {@link String} containing the parameters of the function call
	 * that caused this {@link DSIException}.
	 */
	private String params;

	private Throwable cause;

	/**
	 * Creates a new DSI exception with the given message and {@link Throwable}
	 * and call parameters.
	 * 
	 * @param mesg
	 *            the message
	 * @param t
	 *            the {@link Throwable}
	 * @param callParameters
	 *            a {@link String} containing the function parameters of the
	 *            function call that caused this {@link DSIException}
	 */
	public DSIException(String mesg, Throwable t, String callParameters) {
		super(mesg);
		this.cause = t;
		this.params = callParameters;
	}

	public String getMessage() {
		if (cause == null)
			return super.getMessage();
		else
			return super.getMessage() + " (" + cause.toString() + ")";
	}

	public void printStackTrace() {
		printStackTrace(System.err);
	}

	public void printStackTrace(PrintStream output) {
		synchronized (output) {
			if (cause != null) {
				output.print(getClass().getName() + ": ");
				cause.printStackTrace(output);
			} else {
				super.printStackTrace(output);
			}
		}
	}

	public void printStackTrace(PrintWriter output) {
		synchronized (output) {
			if (cause != null) {
				output.print(getClass().getName() + ": ");
				cause.printStackTrace(output);
			} else {
				super.printStackTrace(output);
			}
		}
	}

	/**
	 * Returns a {@link String} containing the parameters of the function call
	 * that caused this {@link DSIException}.
	 * 
	 * @return {@link String} with the parameters of the function call
	 */
	public String getCallParams() {
		return params;
	}

	public Throwable getCause() {
		return cause;
	}

}
