/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.base;

/**
 * An interface for an adaptable object factory.
 * 
 * @see org.dsi.ifc.base.IAdapterManager
 * 
 * @mib.state APPROVED
 * @mib.common
 */
public interface IFactory {

	/**
	 * Returns an object which is an instance of the given class associated with
	 * this object. Returns <code>null</code> if no such object can be found.
	 * 
	 * @param adapter
	 *            the adapter class to look up
	 * @return a object castable to the given class, or <code>null</code> if
	 *         this object does not have an adapter for the given class
	 */
	public Object getFactory(Class factoryType);

	/**
	 * Returns a list of available adapter classes for this factory.
	 * 
	 * @return a lits of available adapter classes or an empty list if none.
	 */
	public Class[] getFactoryList();

	/**
	 * Callback method from {@link IAdapterManager} to handle conflicting
	 * adapter factory registrations.
	 * 
	 * @param registeredFactory
	 *            already registered factory
	 * @return <code>true</code> if this factory should override the already
	 *         registered factory; otherwise <code>false</code>.
	 * 
	 * @see IAdapterManager#registerFactories(IFactory)
	 */
	public boolean shouldOverride(IFactory registeredFactory);

}
