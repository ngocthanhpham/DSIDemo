package com.lge.mib3oi.dsi;

/**
 * @author swapan.pati@lge.com
 *
 */

public class Handler extends Thread{
	private  MessageQueue queue = DSIProvider.getDSIInstance().getProviderMsgQueueInstance();
	private  MessageQueue listenerqueue = DSIProvider.getDSIInstance().getListenerMsgQueueInstace();
	
	static {
		 try {  
		    	System.loadLibrary("libDSINative");
		    } catch (UnsatisfiedLinkError e) {
		      System.err.println("DSI Native Library failed to load.\n" + e);
		      e.printStackTrace(System.out);
		      System.exit(1);
	    }
	}
	
	public Handler (){
		initDsiNative();
	}
	

	public native void initDsiNative();
	
	
/**
 * This is the Downward JNI call for All DSI communication from Java & Native
**/
	public native int sendMessage(byte[] msg, int domainId, int interfaceId);
	
/**
 * This is the Upward call from Native to Java
 * Getting the Message from Native & posting into the Listener Message Queue
**/ 	
	public static void sendResponseMessage(byte[] responseMsg, int domainId, int interfaceId){
		DSIProvider.getDSIInstance().postDSIListenerMsg(responseMsg,domainId, interfaceId);
	}
			
	public void run(){
		int result = 0;
		while (true){
			
			synchronized (queue){
				while (queue != null && queue.isEmpty()) {
					try {
						queue.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
			
			if (queue != null && !queue.isEmpty()){
				Message msg = queue.deleteMessage();
				if (msg != null){
					try{
						result = sendMessage(msg.getData(), msg.getDomainId(), msg.getInterfaceId());
						if (result != 0){
							//Needs to update the Exception to HMI
						}
					}catch (Exception  e){
						System.out.println("Error: " + e);
					 }
				}
			}
		}
	}
}
