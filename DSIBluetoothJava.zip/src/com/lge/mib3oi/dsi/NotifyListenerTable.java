/**
 * File created by Swapan (swapan.pati@lge.com)
 */
package com.lge.mib3oi.dsi;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.dsi.ifc.base.DSIListener;

/**
 * @author swapan.pati
 *
 */
public class NotifyListenerTable {
	private HashMap<Integer, List<DSIListener>> listenerTable = null;
	
	public NotifyListenerTable (HashMap<Integer, List<DSIListener>> listenerTable){
		this.listenerTable = listenerTable;
	}
	

	public void setNotification(int[] attributes, DSIListener listener){
		for (int i =0; i<attributes.length; i++){
			setNotification(attributes[i], listener);
		}
	}
	
	public void setNotification(int attribute, DSIListener listener){
		
		List<DSIListener> listenerList = new LinkedList<DSIListener>();
		
		if (listenerTable.containsKey(attribute)){
			if (listenerTable.get(attribute) == null){
				listenerList.add(listener);
			}else{
				listenerList = listenerTable.get(attribute);
				if (listenerList.contains(listener)) return;
				listenerList.add(listener);
			}
			listenerTable.remove(attribute);
		}
		else{
			listenerList.add(listener);
		}
		listenerTable.put(new Integer(attribute), listenerList);
		
	}
	
	public void clearNotification(int[] attributes, DSIListener listener) {
		for (int i =0; i<attributes.length; i++){
			clearNotification(attributes[i], listener);
		}
	}
	
	public void clearNotification(int attribute, DSIListener listener) {
		List<DSIListener> listenerList = new LinkedList<DSIListener>();
			
		if (listenerTable.containsKey(attribute)){
			if (listenerTable.get(attribute) == null){
				return;
			}else{
				listenerList = listenerTable.get(attribute);
				if (listenerList.contains(listener)){
					listenerList.remove(listener);
				}
				listenerTable.remove(attribute);
				listenerTable.put(new Integer(attribute), listenerList);
			}
			
		}
	}
}
