package com.vw.mib3oi;

/**
 * @author swapan.pati@lge.com
 *
 */

public class TestDSI {
	
	public static void main(String[] args) {
		
		
	
		// TODO Auto-generated method stub
		Thread hmi = new HMI();
		hmi.setName("HMI_ASL_Thread");
		hmi.start();
		
	}

}
