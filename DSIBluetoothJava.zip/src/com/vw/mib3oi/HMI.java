package com.vw.mib3oi;
import org.dsi.ifc.bluetooth.DSIBluetoothLE;
import org.dsi.ifc.bluetooth.lge.*;

/**
 * @author swapan.pati@lge.com
 *
 */

public class HMI extends Thread{
	DSIBluetoothLE dsi = new DSIBluetoothLEImpl();
	public void run(){
		
		int i =0;
			
		while (true){
			dsi.requestPasskeyResponse("9999", "10.20.10.100", 1);
			dsi.requestRemoveAuthentication("10:200:30:222");
			dsi.requestNotifyCharacteristicValue("12345", "Success");	
		//	dsi.setNotification(listener);
		//	int array[] = {DSIBluetoothLE.ATTR_BTSTATE, DSIBluetoothLE.ATTR_CHARACTERISTICVALUE};
		//	dsi.setNotification(array, listener1);
		//	dsi.clearNotification(DSIBluetoothLE.ATTR_BTSTATE, listener1);
			i++;
			if (i >= 1)break;
		}
		
	}
}