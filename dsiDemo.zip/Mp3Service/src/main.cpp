/*
 * main.cpp
 *
 *  Created on: Nov 21, 2017
 *      Author: thanhpn
 */
#include "../header/ServerTCP.h"

#include <iomanip>        // std::put_time
#include <thread>         // std::this_thread::sleep_until
#include <chrono>         // std::chrono::system_clock
#include <ctime>

int main(int argc, char **argv) {
	std::cout << "Start server\n";
	ServerTCP srv(1234);
	srv.run();
	while (true) {
		if (!(ServerTCP::isRecvDone && ServerTCP::isSendDone)) {
			sleep(1);
		} else {
			std::cout << "Stop Server..." << std::endl;
			break;
		}
	}
}

