/*
 * ServerTCP.cpp
 *
 *  Created on: Nov 21, 2017
 *      Author: thanhpn
 */

#include "../header/ServerTCP.h"

bool ServerTCP::isRecvDone = false;
bool ServerTCP::isSendDone = false;


Queue<DSISERVICEMSG_T> ServerTCP::dsiQueue;
ServerTCP::ServerTCP(int portNo) :
		newSokcfd(0), sockfd(0), portNo(portNo) {

	if (portNo == 0) {
		error("ERROR, no port provided\n");
	}

	dsiMsg.idMsg = 96;
	strcpy(dsiMsg.msg, "DSI message from server");

}

void ServerTCP::run() {
//	t1 = std::thread(&ServerTCP::start, this);
	start();
}

void ServerTCP::start() {

	struct sockaddr_in servAddr = { 0 };
	struct sockaddr_in clientAddr = { 0 };

	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (sockfd < 0)
		error("ERROR, cant open the socket\n");

	servAddr.sin_family = AF_INET;
	servAddr.sin_addr.s_addr = INADDR_ANY; // automatically be filled with current host's IP address
	servAddr.sin_port = htons(portNo);

	if (bind(sockfd, (struct sockaddr*) (&servAddr), sizeof(servAddr)) < 0)
		error("ERROR, cant binding socket\n");
	else
		std::cout << "INFO, bind success socket: "
				<< inet_ntoa(servAddr.sin_addr) << ":"
				<< ntohs(servAddr.sin_port) << std::endl;

	listen(sockfd, 10);
	socklen_t clientLength = sizeof(clientAddr);
	newSokcfd = accept(sockfd, (struct sockaddr*) (&clientAddr), &clientLength);
	std::cout << "Accepted new connection: " << inet_ntoa(clientAddr.sin_addr)
			<< ":" << ntohs(clientAddr.sin_port) << std::endl;

	sendMsgProcess = std::thread(&ServerTCP::sendMsg, this);
	sendMsgProcess.detach();
	recvMsgProcess = std::thread(&ServerTCP::recvMsg, this);
	recvMsgProcess.detach();
}

ServerTCP::~ServerTCP() {
//	t1.join();
	stop();
}

void ServerTCP::error(const char *msg) {
	std::cout << msg << std::endl;
	exit(1);
}

void ServerTCP::stop() {
	close(newSokcfd);
	close(sockfd);

}

void ServerTCP::handlerMsg(const DSISERVICEMSG_T* msg) {
	if(msg->idMsg == 208){
		std::cout << "Received: " << msg->idMsg << "-" << msg->msg << std::endl;
		DSISERVICEMSG_T msgResponse;
		msgResponse.idMsg = 211;
		char msg[]= "songID-1;songName-Em gai mua;duration-3600;StateSong-1";
		strncpy(msgResponse.msg, msg, sizeof(msg));
		dsiQueue.push(msgResponse);
	}

}

void ServerTCP::sendMsg() {
	std::cout << "Start sendMsg process..." << std::endl;
	while (true) {

		DSISERVICEMSG_T dsiMsg;
		dsiQueue.pop(dsiMsg);
		int n = send(newSokcfd, &dsiMsg, sizeof(dsiMsg), 0);
		if (n < 0) {
			isSendDone = true;
			error("ERROR, sending from socket server");
		}
	}
	sleep(2000);
}

void ServerTCP::recvMsg() {
	std::cout << "Start recvMsg process..." << std::endl;
	DSISERVICEMSG_T msg;
	while (true) {
		int n = read(newSokcfd, &msg, sizeof(msg));
		if (n < 0) {
			isRecvDone = true;
			error("ERROR, reading from socket server");
		}
		handlerMsg(&msg);
	}
}
