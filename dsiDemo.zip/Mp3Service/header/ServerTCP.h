/*
 * ServerTCP.h
 *
 *  Created on: Nov 21, 2017
 *      Author: thanhpn
 */

#ifndef SERVERTCP_H_
#define SERVERTCP_H_
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <cstring>
#include <thread>
#include "MessageQueue.h"

#define KIPC_MSG_SIZE 4096

typedef struct dsiServiceMsg {
	int idMsg;
	char msg[KIPC_MSG_SIZE] = { 0 };
} DSISERVICEMSG_T;

class ServerTCP {
public:
	ServerTCP(int);
	virtual ~ServerTCP();
	void run();

	static bool isSendDone;
	static bool isRecvDone;
	static Queue<DSISERVICEMSG_T> dsiQueue;
private:
	int newSokcfd;
	int sockfd;
	int portNo;

	std::thread t1;
	void start();
	void error(const char*);
	void stop();
	void handlerMsg(const DSISERVICEMSG_T*);
	void sendMsg();
	void recvMsg();


	std::thread sendMsgProcess;
	std::thread recvMsgProcess;
	DSISERVICEMSG_T dsiMsg;
};

#endif /* SERVERTCP_H_ */
