/**
 * File created by Swapan (swapan.pati@lge.com)
 */
package com.lge.mib3oi.dsi;

/**
 * @author swapan.pati
 *
 */
public class DSIDomain {
 public final static int BLUETOOTH = 100;
 public final static int MEDIA = 101;
 public final static int DISPLAYMANAGER =102;
 public final static int MP3 = 103;
}
