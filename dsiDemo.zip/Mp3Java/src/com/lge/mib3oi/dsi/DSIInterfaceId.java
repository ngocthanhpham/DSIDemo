/**
 * File created by Swapan (swapan.pati@lge.com)
 */
package com.lge.mib3oi.dsi;

/**
 * @author swapan.pati
 *
 */
public class DSIInterfaceId {

// Bluetooth DSI Interface List..
	 public final static int DSIBluetooth = 1;
	 public final static int DSIBluetoothListener = 2;
	 public final static int DSIBluetoothLEDataChannel = 3;
	 public final static int DSIBluetoothLEDataChannelListener = 4;
	 public final static int DSIBluetoothLE = 5;
	 public final static int DSIBluetoothLEListener = 6;
	 
// Display DSI Interface List...
	 public final static int DSIDisplayManagement = 100;
	 public final static int DSIDisplayManagementListener = 101;	 
	
// Media  DSI Interface List..
	 public final static int DSIMediaBase = 200;
	 public final static int DSIMediaBaseListener = 201;
	 public final static int DSIMediaBrowser = 202;
	 public final static int DSIMediaBrowserListener = 203;
	 public final static int DSIMediaOnline = 204; 
	 public final static int DSIMediaOnlineListener = 205;
	 public final static int DSIMediaPlayer = 205;
	 public final static int DSIMediaPlayerListener = 207;
	 
	 //MP3 DSI Interface List...
	 public final static int DSIMP3PlayMusic = 208;
	 public final static int DSIMP3PauseMusic = 209;
	 public final static int DSIMP3ListMusics = 210;

}
