package com.lge.mib3oi.dsi;

/**
 * @author swapan.pati@lge.com
 *
 */
final class DomainID {
	public static int Bluetooth = 1;
}

public class ListenerWorkerThread implements Runnable {
	private Message msg;

	public ListenerWorkerThread(Message msg) {
		this.msg = msg;
	}

	@Override
	public void run() {

		switch (msg.getDomainId()) {
		case DSIDomain.BLUETOOTH: {
			// switch(msg.getInterfaceId()){
			// case DSIInterfaceId.DSIBluetoothLEListener:
			// {
			// DSIBluetoothLEListenerService listener = new
			// DSIBluetoothLEListenerService(msg);
			// listener.executeListenerService();
			// }
			// break;
			// case DSIInterfaceId.DSIBluetoothListener:
			// break;
			// default:
			// break;
			// }
		}
		case DSIDomain.MP3:
			break;
		case DSIDomain.MEDIA:
			break;
		case DSIDomain.DISPLAYMANAGER:
			break;
		default:
			break;
		}
	}

}
