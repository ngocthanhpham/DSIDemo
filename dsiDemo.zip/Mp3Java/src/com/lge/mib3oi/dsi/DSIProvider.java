/**
 * File created by Swapan (swapan.pati@lge.com)
 */
package com.lge.mib3oi.dsi;

import org.dsi.ifc.mp3.DSIMP3Handler;

/**
 * @author swapan.pati
 *
 */
public class DSIProvider {
	
	private  MessageQueue providerMsgQueue = getProviderMsgQueueInstance();
	private  MessageQueue listenerMsgQueue = getListenerMsgQueueInstace();
	
	private  static DSIMP3Handler handler = getHandlerInstance();
	private  static ListenerHandler listenerhanlder = getListenerHanlderInstance();
	
	private  static DSIProvider dsiprovider= getDSIInstance();
	
	public static DSIProvider getDSIInstance(){
		if (dsiprovider == null){
			dsiprovider = new DSIProvider();
			dsiprovider.startDSIProvider();
		}
		return dsiprovider;
	}

	public  MessageQueue getProviderMsgQueueInstance(){
		if (providerMsgQueue == null){
			providerMsgQueue = new MessageQueue();
		}
		return providerMsgQueue;
	}

	public  MessageQueue getListenerMsgQueueInstace(){
		if (listenerMsgQueue == null){
			listenerMsgQueue = new MessageQueue();
		}
		return listenerMsgQueue;
	}
	
	public static DSIMP3Handler getHandlerInstance(){
		if (handler == null){
			handler = new DSIMP3Handler();
		}
		return handler;
	}
	
	public static ListenerHandler getListenerHanlderInstance(){
		if (listenerhanlder == null){
			listenerhanlder = new ListenerHandler();
		}
		return listenerhanlder;
	}
	
	public void startDSIProvider(){
		getHandlerInstance().setName("DSIProvider");
		getHandlerInstance().start();
		
		getListenerHanlderInstance().setName("DSIListener");
		getListenerHanlderInstance().start();
		
	}
	
	public void postDSIProviderMsg(byte[] msg, int domainid, int interfaceId){
		synchronized(providerMsgQueue){
			providerMsgQueue.postMessage(msg, domainid,interfaceId);
			providerMsgQueue.notify();
		}
	}
	
	public void postDSIListenerMsg(byte[] msg, int domainid, int interfaceId){
		synchronized(listenerMsgQueue){
			listenerMsgQueue.postMessage(msg, domainid,interfaceId);
			listenerMsgQueue.notify();
		}
	}
}
