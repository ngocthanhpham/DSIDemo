package org.dsi.ifc.mp3;

public class DSIMP3HMI extends Thread {
	DSIMP3 dsi = new DSIMP3();

	public void run() {
		int i = 0;
		while (true) {
			dsi.requestPlayMusic(1);
			i++;
			if (i >= 0)
				break;
		}
	}

}
