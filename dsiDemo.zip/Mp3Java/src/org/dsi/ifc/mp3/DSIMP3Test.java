package org.dsi.ifc.mp3;

public class DSIMP3Test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread hmi = new DSIMP3HMI();
		hmi.setName("HMI_ASL_Thread");
		hmi.start();
		
	}
}
