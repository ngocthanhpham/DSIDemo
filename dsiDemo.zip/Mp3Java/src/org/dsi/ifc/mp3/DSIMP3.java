package org.dsi.ifc.mp3;



/**

 * @author thanhpn

 *

 */
import com.lge.mib3oi.dsi.DSIProvider;
import com.lge.mib3oi.dsi.DSIDomain;
import com.lge.mib3oi.dsi.DSIInterfaceId;

import org.dsi.ifc.mp3.DSIMp3MsgProto.RequestPauseMusic;
import org.dsi.ifc.mp3.DSIMp3MsgProto.RequestPlayMusic;

public class DSIMP3 {
	public DSIProvider dsi = DSIProvider.getDSIInstance();
	
	public DSIMP3() {
	}
	
	
	public void requestPlayMusic(int songID){
		RequestPlayMusic.Builder rqPlay = RequestPlayMusic.newBuilder();
		rqPlay.setSongID(songID);
		
		byte[] msg = rqPlay.build().toByteArray();
		dsi.postDSIProviderMsg(msg, DSIDomain.MP3, DSIInterfaceId.DSIMP3PlayMusic);
	}
	
	public void requestPauseMusic(int songID){
		RequestPauseMusic.Builder rqPause = RequestPauseMusic.newBuilder();
		rqPause.setSongID(songID);
		
		byte[] msg = rqPause.build().toByteArray();
		dsi.postDSIProviderMsg(msg, DSIDomain.MP3, DSIInterfaceId.DSIMP3PauseMusic);
	}
	
	public void getListMusics(){
		byte[] msg = null;
		dsi.postDSIProviderMsg(msg, DSIDomain.MP3, DSIInterfaceId.DSIMP3ListMusics);
	}
	
}
