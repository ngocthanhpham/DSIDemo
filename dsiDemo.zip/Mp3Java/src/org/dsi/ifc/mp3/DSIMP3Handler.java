package org.dsi.ifc.mp3;

import com.lge.mib3oi.dsi.DSIProvider;
import com.lge.mib3oi.dsi.Message;
import com.lge.mib3oi.dsi.MessageQueue;

public class DSIMP3Handler extends Thread {
	private MessageQueue queue = DSIProvider.getDSIInstance().getProviderMsgQueueInstance();
	private MessageQueue listenerQueue = DSIProvider.getDSIInstance().getListenerMsgQueueInstace();

	static {
		try {
			System.load("/home/thanhpn/WorkSpace/Mp3Native/Debug/libMp3Native.so");
		} catch (UnsatisfiedLinkError e) {
			System.err.println("DSI Native Library failed to load.\n" + e);
			e.printStackTrace(System.out);
			System.exit(1);
		}
	}

	public DSIMP3Handler() {
		initDsiNative();
	}

	public native void initDsiNative();

	public native int sendMessage(byte[] msg, int domaintID, int interfaceID);

	public static void sendResponseMessage(byte[] responseMsg, int domainId, int interfaceId) {
		DSIProvider.getDSIInstance().postDSIListenerMsg(responseMsg, domainId, interfaceId);
	}

	public void run() {
		int result = 0;
		while (true) {

			synchronized (queue) {
				while (queue != null && queue.isEmpty()) {
					try {
						queue.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

			if (queue != null && !queue.isEmpty()) {
				Message msg = queue.deleteMessage();
				if (msg != null) {
					try {
						result = sendMessage(msg.getData(), msg.getDomainId(), msg.getInterfaceId());
						if (result != 0) {
							// Needs to update the Exception to HMI
						}
					} catch (Exception e) {
						System.out.println("Error: " + e);
					}
				}
			}
		}
	}

}
