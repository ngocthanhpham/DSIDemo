/*
 * DSIMP3HandlerKIPCMsg.h
 *
 *  Created on: Nov 24, 2017
 *      Author: thanhpn
 */

#ifndef DSIMP3HANDLERKIPCMSG_H_
#define DSIMP3HANDLERKIPCMSG_H_

class DSIMP3HandlerKIPCMsg {
public:
	DSIMP3HandlerKIPCMsg();
	virtual ~DSIMP3HandlerKIPCMsg();
};

#endif /* DSIMP3HANDLERKIPCMSG_H_ */
