/*
 * DSIMP3Service.h
 *
 *  Created on: Nov 24, 2017
 *      Author: thanhpn
 */

#ifndef DSIMP3SERVICE_H_
#define DSIMP3SERVICE_H_

#include "../header/org_dsi_ifc_mp3_DSIMP3Handler.h"
#include "../header/DSIMP3.pb.h"
#include "../header/DSIMP3HandlerDSIMsg.h"
#include "../header/DSIMP3HandlerKIPCMsg.h"
#include "../header/DSIMP3Socket.h"

class DSIMP3Service {
public:
	DSIMP3Service();
	virtual ~DSIMP3Service();
	static DSIMP3HandlerDSIMsg handlerDsiMsg;
	static DSIMP3HandlerKIPCMsg hanlderKipcMsg;
	static DSIMP3Socket soc;
private:

	void sendDSIMP3Response(void* data, int msgSize, int domainID,
			int interfaceID);
};

#endif /* DSIMP3SERVICE_H_ */
