/*
 * DSIMP3HandlerDSIMsg.h
 *
 *  Created on: Nov 24, 2017
 *      Author: thanhpn
 */

#ifndef DSIMP3HANDLERDSIMSG_H_
#define DSIMP3HANDLERDSIMSG_H_

#include <iostream>
#include <stdio.h>
#include <map>
#include "../header/DSIDomain.h"
#include "../header/DSIError.h"
#include "../header/DSIMP3.pb.h"
#include "../header/DSIInterfaceID.h"
#include "../header/MessageQueue.h"

typedef std::map<int, std::string> DSIMessage;

class DSIMP3HandlerDSIMsg {
public:
	DSIMP3HandlerDSIMsg();
	virtual ~DSIMP3HandlerDSIMsg();

	void handlerDSIMsg(char* msg, int size, int interfaceId);
	void sendResponseDSIMsg();

	static Queue<DSIMessage> dsiQueue;
};

#endif /* DSIMP3HANDLERDSIMSG_H_ */
