class DSIDomain {
public:
	static const int BLUETOOTH = 100;
	static const int MEDIA = 101;
	static const int DISPLAYMANAGER = 102;
	static const int MP3 = 103;
};
