/*
 * ClientTCP.h
 *
 *  Created on: Nov 21, 2017
 *      Author: thanhpn
 */

#ifndef CLIENTTCP_H_
#define CLIENTTCP_H_

#include <iostream>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <cstdlib>
#include <thread>
#include "../header/DSIMP3HandlerDSIMsg.h"


#define KIPC_MSG_SIZE 4096

typedef struct dsiServiceMsg {
	int idMsg;
	char msg[KIPC_MSG_SIZE] = { 0 };
} DSISERVICEMSG_T;

class DSIMP3Socket {
public:
	DSIMP3Socket();
	virtual ~DSIMP3Socket();
	void run();
private:
	int sockfd;
	struct hostent *server;
	struct sockaddr_in servAddr;
	int portNo;
	std::thread t1;
	std::thread sendMsgProcess;
	std::thread recvMsgProcess;
	DSISERVICEMSG_T dsiMsg;

	bool isSendDone;
	bool isRecvDone;

	void start();
	void error(const char *msg);
	void stop();

	void sendMsg();
	void receiveMsg();
};

#endif /* CLIENTTCP_H_ */
