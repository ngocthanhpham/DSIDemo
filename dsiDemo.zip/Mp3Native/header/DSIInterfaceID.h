class DSIInterfaceId{
public:

// Bluetooth DSI Interface List..
	static const int DSIBluetooth = 1;
	static const int  DSIBluetoothListener = 2;
	static const int DSIBluetoothLEDataChannel = 3;
	static const int DSIBluetoothLEDataChannelListener = 4;
	static const int DSIBluetoothLE = 5;
	static const int DSIBluetoothLEListener = 6;

// Display DSI Interface List...
	static const int DSIDisplayManagement = 100;
	static const int DSIDisplayManagementListener = 101;

// Media  DSI Interface List..
	static const int DSIMediaBase = 200;
	static const int DSIMediaBaseListener = 201;
	static const int DSIMediaBrowser = 202;
	static const int DSIMediaBrowserListener = 203;
	static const int DSIMediaOnline = 204;
	static const int DSIMediaOnlineListener = 205;
	static const int DSIMediaPlayer = 205;
	static const int DSIMediaPlayerListener = 207;


	 //MP3 DSI Interface List...
	 static const int DSIMP3PauseMusicRequest = 209;
	 static const int DSIMP3PlayMusicRequest = 208;
	 static const int DSIMP3ListMusics = 210;
	 static const int DSIMP3PlayMusicResponse = 211;
};
