/*
 * DSIMP3Service.cpp
 *
 *  Created on: Nov 24, 2017
 *      Author: thanhpn
 */

#include "../header/DSIMP3Service.h"


static JNIEnv *javaEnv = NULL;
static jclass dsiClass = NULL;
static jmethodID dsiResponseMethod = NULL;

const char* dsiClassPath = "org/dsi/ifc/mp3/DSIMP3Handler";
const char* dsiResponseMethodName = "sendResponseMessage";

DSIMP3HandlerDSIMsg DSIMP3Service::handlerDsiMsg;
DSIMP3HandlerKIPCMsg DSIMP3Service::hanlderKipcMsg;
DSIMP3Socket DSIMP3Service::soc;

DSIMP3Service::DSIMP3Service() {
	// TODO Auto-generated constructor stub

}

DSIMP3Service::~DSIMP3Service() {
	// TODO Auto-generated destructor stub
}

jint JNI_OnLoad(JavaVM* vm, void* /*reserved*/){
	DSIMP3Service::soc.run();
	return JNI_VERSION_1_8;
}

JNIEXPORT void JNICALL Java_org_dsi_ifc_mp3_DSIMP3Handler_initDsiNative(
		JNIEnv *env, jobject obj) {
	if (javaEnv == NULL) {
		javaEnv = env;
	}
	if (dsiClass == NULL) {
		dsiClass = javaEnv->FindClass(dsiClassPath);
	}
	if (dsiResponseMethod == NULL) {
		dsiResponseMethod = javaEnv->GetStaticMethodID(dsiClass,
				dsiResponseMethodName, "([BII)V");
	}
}

JNIEXPORT jint JNICALL Java_org_dsi_ifc_mp3_DSIMP3Handler_sendMessage(
		JNIEnv *env, jobject object, jbyteArray buffer, jint domainID, jint interfaceID) {

	int result = -1;
	javaEnv = env;

	int length = env->GetArrayLength(buffer);
	if (length <= 0)
		return DSIError::ERROR_INVALID_ARGUMENT;

	jbyte *msg = env->GetByteArrayElements(buffer, 0);

	switch (domainID) {

	case DSIDomain::MP3: {
		DSIMP3Service::handlerDsiMsg.handlerDSIMsg((char*)msg, length, interfaceID);
	};
		break;
	case DSIDomain::BLUETOOTH: // Bluetooth Domain
		break;
	case DSIDomain::MEDIA: // Media Domaina
		break;
	case DSIDomain::DISPLAYMANAGER: //DisplayManager Domain
		break;
	default:
		break;
	}

	return result;
}

void DSIMP3Service::sendDSIMP3Response(void* data, int msgSize, int domainID,
		int interfaceID) {

}
