/*
 * main.cpp
 *
 *  Created on: Nov 21, 2017
 *      Author: thanhpn
 */
#include "../header/DSIMP3Socket.h"

//int main(int argc, char **argv) {
//	std::cout << "Start app client\n";
////	DSIMP3Middle cli(1234, "localhost");
////	cli.run();
//}

