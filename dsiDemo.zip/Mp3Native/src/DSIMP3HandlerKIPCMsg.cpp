/*
 * DSIMP3HandlerKIPCMsg.cpp
 *
 *  Created on: Nov 24, 2017
 *      Author: thanhpn
 */

#include "../header/DSIMP3HandlerKIPCMsg.h"

DSIMP3HandlerKIPCMsg::DSIMP3HandlerKIPCMsg() {
	// TODO Auto-generated constructor stub

}

DSIMP3HandlerKIPCMsg::~DSIMP3HandlerKIPCMsg() {
	// TODO Auto-generated destructor stub
}

