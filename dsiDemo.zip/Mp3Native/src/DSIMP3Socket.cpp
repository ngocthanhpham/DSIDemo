/*
 * ClientTCP.cpp
 *
 *  Created on: Nov 21, 2017
 *      Author: thanhpn
 */

#include "../header/DSIMP3Socket.h"

DSIMP3Socket::DSIMP3Socket() {
	sockfd = 0;
	portNo = 1234;
	server = gethostbyname("localhost");

	isRecvDone = false;
	isSendDone = false;
//	if (server == NULL)
//		error("ERROR, no such host\n");
//	else{
//		std::cout << (char*)server->h_addr_list << std::endl;
//	}

//	start();
}

DSIMP3Socket::~DSIMP3Socket() {
	stop();
}

void DSIMP3Socket::error(const char* msg) {
	std::cout << msg << std::endl;
	exit(1);
}

void DSIMP3Socket::run() {
//	t1 = std::thread(&DSIMP3Socket::start, this);
	std::cout << "run start" << std::endl;
	start();
}

void DSIMP3Socket::start() {

	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (sockfd < 0)
		error("ERROR, opening socket\n");

	servAddr.sin_port = htons(portNo);
	servAddr.sin_family = AF_INET;
	servAddr.sin_addr.s_addr = INADDR_ANY;

	if (connect(sockfd, (struct sockaddr*) &servAddr, sizeof(servAddr)) < 0)
		error("ERROR, cant connect to server");

	sendMsgProcess = std::thread(&DSIMP3Socket::sendMsg, this);
	sendMsgProcess.detach();
	recvMsgProcess = std::thread(&DSIMP3Socket::receiveMsg, this);
	recvMsgProcess.detach();

}

void DSIMP3Socket::stop() {
	while (true) {
		if (!(DSIMP3Socket::isRecvDone && DSIMP3Socket::isSendDone)) {
			sleep(1);
		} else {
			std::cout << "Stop Client..." << std::endl;
			break;
		}
	}
	close(sockfd);
}

void DSIMP3Socket::sendMsg() {
	std::cout << "Start sendMsg process..." << std::endl;
	char buffer[512] = "Hello from client\n";

	while (true) {
		DSISERVICEMSG_T kipcMsg;
		DSIMessage dsiMsg;

		DSIMP3HandlerDSIMsg::dsiQueue.pop(dsiMsg);

		std::cout << "sending kipcMsg to server" << std::endl;

		kipcMsg.idMsg = dsiMsg.begin()->first;
		strncpy(kipcMsg.msg, dsiMsg.begin()->second.c_str(),
				sizeof(dsiMsg.begin()->second.c_str()));

		int n = write(sockfd, &kipcMsg, strlen(buffer));

		if (n < 0) {
			isSendDone = true;
			error("ERROR, Writing to the socket\n");
		}
		sleep(2000);
	}

}

void DSIMP3Socket::receiveMsg() {
	std::cout << "Start receiveMsg process..." << std::endl;
	while (true) {
		int n = read(sockfd, &dsiMsg, sizeof(dsiMsg));
		if (n < 0) {
			isRecvDone = true;
			error("ERROR, reading from socket\n");
		}
		std::cout << "Received: " << dsiMsg.idMsg << "-" << dsiMsg.msg << std::endl;
	}

}
