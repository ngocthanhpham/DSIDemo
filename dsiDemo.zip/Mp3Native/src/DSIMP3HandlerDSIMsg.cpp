/*
 * DSIMP3HandlerDSIMsg.cpp
 *
 *  Created on: Nov 24, 2017
 *      Author: thanhpn
 */

#include "../header/DSIMP3HandlerDSIMsg.h"

Queue<DSIMessage> DSIMP3HandlerDSIMsg::dsiQueue;

DSIMP3HandlerDSIMsg::DSIMP3HandlerDSIMsg() {

}

DSIMP3HandlerDSIMsg::~DSIMP3HandlerDSIMsg() {
}

void DSIMP3HandlerDSIMsg::handlerDSIMsg(char* msg, int size, int interfaceId) {
	switch(interfaceId){
	case DSIInterfaceId::DSIMP3ListMusics:{

	}
	break;

	case DSIInterfaceId::DSIMP3PlayMusicRequest:{
		proto::RequestPauseMusic rq;
		rq.ParseFromArray(msg, size);

		DSIMessage dsiMsg;
		dsiMsg.insert(std::pair<int, std::string>(208, std::to_string(rq.songid())));
		dsiQueue.push(dsiMsg);

		std::cout << "Receive request play song: " <<rq.songid() << std::endl;
	}
	break;

	case DSIInterfaceId::DSIMP3PauseMusicRequest:
	break;

	default:
	break;
	}
}

void DSIMP3HandlerDSIMsg::sendResponseDSIMsg() {
}
