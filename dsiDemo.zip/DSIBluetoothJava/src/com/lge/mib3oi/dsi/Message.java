package com.lge.mib3oi.dsi;

import java.util.Arrays;

/**
 * @author swapan.pati@lge.com
 *
 */

public class Message {

	 private int domainId = 0;
	 private int interfaceId = 0;
	 private byte[]  data = null;
	
	  public Message(byte[] val, int domainId, int interfaceId) {
		  this.domainId = domainId;
		  this.interfaceId = interfaceId;
		  this.data = Arrays.copyOf(val, val.length);
	  }

	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}

	/**
	 * @return the domainId
	 */
	public int getDomainId() {
		return domainId;
	}

	/**
	 * @param domainId the domainId to set
	 */
	public void setDomainId(int domainId) {
		this.domainId = domainId;
	}

	/**
	 * @return the module
	 */
	public int getInterfaceId() {
		return interfaceId;
	}

	/**
	 * @param module the module to set
	 */
	public void setInterfaceId(int interfaceId) {
		this.interfaceId = interfaceId;
	}

}
