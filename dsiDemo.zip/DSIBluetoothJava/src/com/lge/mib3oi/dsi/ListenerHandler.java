package com.lge.mib3oi.dsi;

/**
 * @author swapan.pati@lge.com
 *
 */

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ListenerHandler extends Thread{
	private MessageQueue queue = DSIProvider.getDSIInstance().getListenerMsgQueueInstace();
	
// Creating Fixed Threadpool to execute the DSI Listener callback..	
	ExecutorService executor = Executors.newFixedThreadPool(5);
	
	public void run(){
		while(true){
			synchronized (queue){
				while (queue != null && queue.isEmpty()) {
					try {
						queue.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
			if (queue != null && !queue.isEmpty()){
				Message msg = queue.deleteMessage();
				executor.execute(new ListenerWorkerThread(msg));
			}
		}
	}

}
