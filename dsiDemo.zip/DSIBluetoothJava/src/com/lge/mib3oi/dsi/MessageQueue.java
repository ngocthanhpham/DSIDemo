package com.lge.mib3oi.dsi;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @author swapan.pati@lge.com
 *
 */

public class MessageQueue {

private ConcurrentLinkedQueue<Message> queue = null;
	
public MessageQueue() {
     queue =  new ConcurrentLinkedQueue<Message>();
}

public Message deleteMessage() {
		return queue.poll();
}

public boolean isEmpty() { return (queue.isEmpty()); }

public void postMessage(byte[]  val, int domainId, int interfaceId) {
	if (val.length == 0) return;
	Message msg = new Message(val, domainId, interfaceId);
	if (msg != null){
		queue.add(msg);  
	}
} 

public int queueSize(){
	return queue.size();
}

}  // end class