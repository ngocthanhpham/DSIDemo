package com.vw.mib3oi;

import org.dsi.ifc.bluetooth.BleService;
import org.dsi.ifc.bluetooth.DSIBluetoothLEListener;
import org.dsi.ifc.bluetooth.PasskeyStateStruct;
import org.dsi.ifc.bluetooth.TrustedLEDevice;

/**
 * @author swapan.pati@lge.com
 *
 */

public class DSIBluetoothLEListenerImpl implements DSIBluetoothLEListener{

	@Override
	public void asyncException(int errorCode, String errorMsg, int requestType) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void responsePasskeyResponse(String btDeviceAddress,
			String btDeviceName, int result) {
		// TODO Auto-generated method stub
		System.out.println("responsePasskeyResponse Listener Reponse: " + btDeviceAddress + " " + btDeviceName + " " + result);
		
	}

	@Override
	public void responseRemoveAuthentication(String btDeviceAddress,
			String btDeviceName, String result) {
		// TODO Auto-generated method stub
		System.out.println("responseRemoveAuthentication Listener Reponse: " + btDeviceAddress + " " + btDeviceName + " " + result);
		
	}

	@Override
	public void responseSwitchBTState(int result) {
		// TODO Auto-generated method stub
		System.out.println("responseSwitchBTState Listener Reponse: " + result);
		
	}

	@Override
	public void updateBTState(int bTState, int validFlag) {
		// TODO Auto-generated method stub
		System.out.println("updateBTState Listener Reponse: " + bTState + " " + validFlag);
	}

	@Override
	public void responseSetAccessibleMode(int result) {
		// TODO Auto-generated method stub
		System.out.println("Listener Reponse: " + result);
		
	}

	@Override
	public void updateAccessibleMode(int result, int validFlag) {
		// TODO Auto-generated method stub
		
	}

	

	

	@Override
	public void updateUserFriendlyName(String userFriendlyName, int validFlag) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deviceDisconnectionInfo(String btDeviceAddress,
			String btDeviceName, int disconnectionInfo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void responseSetService(int result) {
		// TODO Auto-generated method stub
		System.out.println("responseSetService Listener Reponse: " + result);
		
	}

	

	@Override
	public void responseSetCharacteristicState(int result) {
		// TODO Auto-generated method stub
		System.out.println("responseSetCharacteristicState Listener Reponse: " + result);
		
	}

	@Override
	public void responseNotifyCharacteristicValue(int result) {
		// TODO Auto-generated method stub
		System.out.println("responseNotifyCharacteristicValue Listener Reponse: " + result);
		
	}

	@Override
	public void updateCharacteristicValue(String characteristicUUID,
			String receivedValue, int validFlag) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.dsi.ifc.bluetooth.DSIBluetoothLEListener#updatePasskeyState(org.dsi.ifc.bluetooth.PasskeyStateStruct, int)
	 */
	@Override
	public void updatePasskeyState(PasskeyStateStruct passkeyState,
			int validFlag) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.dsi.ifc.bluetooth.DSIBluetoothLEListener#updateTrustedDevices(org.dsi.ifc.bluetooth.TrustedLEDevice[], int)
	 */
	@Override
	public void updateTrustedDevices(TrustedLEDevice[] trustedleDevices,
			int validFlag) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.dsi.ifc.bluetooth.DSIBluetoothLEListener#updateService(org.dsi.ifc.bluetooth.BleService, int)
	 */
	@Override
	public void updateService(BleService bleService, int validFlag) {
		// TODO Auto-generated method stub
		
	}
	

}
