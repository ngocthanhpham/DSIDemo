/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.bluetooth;

/**
 * interface Constants - constant enum definitions of bluetooth DSI
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 *
 * @mib.state DOCUMENTED
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public interface Constants {

	/**************************************************/
	/***************** AccessibleModes ****************/
	/**************************************************/

	/**
	 * No other accessible mode is applicable.
	 *
	 * @enum AM (accessible mode)
	 * @mib.common
	 */
	public static final int AM_UNSPECIFIED = 0;

	/**
	 * Other devices are kept from finding and connecting to the local device.
	 *
	 * @enum AM (accessible mode)
	 * @mib.common
	 */
	public static final int AM_NOT_ACCESSIBLE = 1;

	/**
	 * The local device answers to inquiries but is not connectable from other
	 * devices.
	 *
	 * @enum AM (accessible mode)
	 * @mib.common
	 */
	public static final int AM_DISCOVERABLE_ONLY = 2;

	/**
	 * Connections from outside can be established but the local device will not
	 * answer to inquiries.
	 *
	 * @enum AM (accessible mode)
	 * @mib.common
	 */
	public static final int AM_CONNECTABLE_ONLY = 3;

	/**
	 * The local device answers to inquiries and name discoveries and is visible
	 * to the surrounding Bluetooth world.
	 *
	 * @enum AM (accessible mode)
	 * @mib.common
	 */
	public static final int AM_GENERAL_ACCESSIBLE = 4;

	/**
	 * The local device is discoverable only for a certain time after the system
	 * was switched on and if the velocity does not exceed a certain limit
	 * (v_threshold), but it is always connectable from the outside.
	 *
	 * @enum AM (accessible mode)
	 * @mib.common
	 */
	public static final int AM_AUTO_DISCOVERABLE_FULL_ACCESSIBLE = 5;

	/**
	 * The local device shall be discoverable for a limited time even if the
	 * speed is greater than v_threshold. After this time the system shall
	 * restore the mode it was in before it was switched to
	 * AM_LIMITED_DISCOVERABLE.
	 *
	 * @enum AM (accessible mode)
	 *
	 * @mib.common
	 */
	public static final int AM_LIMITED_DISCOVERABLE = 6;

	/**
	 * The local device advertising but is not connectable from other devices.
	 * <p>
	 * For Bluetooth LE.
	 *
	 * @enum AM (accessible mode)
	 * @mib.common
	 */
	public static final int AM_ADVERTISING_NOT_CONNECTABLE = 7;

	/**************************************************/
	/************* AuthenticationResponse *************/
	/**************************************************/

	/**
	 * Reject authentication.
	 *
	 * @enum Authentication (Indicates whether to accept or reject
	 *       authentication.)
	 * @mib.common
	 */
	public static final int AUTHENTICATION_REJECT = 0;

	/**
	 * Accept authentication.
	 *
	 * @enum Authentication (Indicates whether to accept or reject
	 *       authentication.)
	 * @mib.common
	 */
	public static final int AUTHENTICATION_ACCEPT = 1;

	/**************************************************/
	/****************** BTState ***********************/
	/**************************************************/

	/**
	 * Bluetooth module is activated and usable
	 *
	 * @enum BTState (Describes the state of the local Bluetooth device.)
	 * @mib.common
	 */
	public static final int BTSTATE_ON = 0;

	/**
	 * Bluetooth module is switched off but can be switched on.
	 *
	 * @enum BTState (Describes the state of the local Bluetooth device.)
	 * @mib.common
	 */
	public static final int BTSTATE_OFF = 1;

	/**
	 * Bluetooth module is not functional.
	 *
	 * @enum BTState (Describes the state of the local Bluetooth device.)
	 * @mib.common
	 */
	public static final int BTSTATE_NOT_FUNCTIONAL = 2;

	/**
	 * Bluetooth module is in the process of switching on.
	 *
	 * @enum BTState (Describes the state of the local Bluetooth device.)
	 * @mib.common
	 */
	public static final int BTSTATE_SWITCHING_ON = 3;

	/**
	 * Bluetooth module is in the process of switching off.
	 *
	 * @enum BTState (Describes the state of the local Bluetooth device.)
	 * @mib.common
	 */
	public static final int BTSTATE_SWITCHING_OFF = 4;

	/**
	 * Bluetooth can not be switched on by the HMI due to disabled BT
	 * functionality.
	 *
	 * @enum BTState (Describes the state of the local Bluetooth device.)
	 * @mib.common
	 */
	public static final int BTSTATE_DIAGNOSE_NOT_ON_ALLOWED = 5;

	/**************************************************/
	/************* ConnectionResponse *****************/
	/**************************************************/

	/**
	 * Reject a service connection request.
	 *
	 * @enum Connection (Indicates whether to accept or reject a service
	 *       connection request.)
	 * @mib.common
	 */
	public static final int CONNECTION_REJECT = 0;

	/**
	 * Accept a service connection request
	 *
	 * @enum Connection (Indicates whether to accept or reject a service
	 *       connection request.)
	 * @mib.common
	 */
	public static final int CONNECTION_ACCEPT = 1;

	/**************************************************/
	/******************* Result ***********************/
	/**************************************************/

	/**
	 * No error occured
	 *
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_OK = 0;

	/**
	 * Further response follows.
	 *
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_INTERMEDIATE = 1;

	/**
	 * Request was aborted.
	 *
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_ABORTED = 2;

	/**
	 * Not further specified error.
	 *
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_ERROR_GENERAL = 3;

	/**
	 * Connection failed
	 *
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_ERROR_PAIRING_GENERAL = 4;

	/**
	 * Connection failed, time went over
	 *
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_ERROR_PAIRING_TIMEOUT = 5;

	/**
	 * Connection failed, pass key was wrong
	 *
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_ERROR_PAIRING_WRONG_PASSKEY = 6;

	/**
	 * Service is not supported.
	 *
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_ERROR_SERVICE_NOT_SUPPORTED = 7;

	/**
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_PAGE_TIMEOUT = 8;

	/**
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_ERROR_INSTANCE_NOT_EXIST = 9;

	/**
	 * @enum Result (results returned in response methods)
	 * @mib.common
	 */
	public static final int RESULT_ERROR_INSTANCE_ALREADY_CONNECTED = 10;

	/**
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_DEVICE_NOT_TRUSTED = 11;

	/**
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_HW_FAILURE = 12;

	/**
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_CONNECTION_LIMIT_EXCEEDED = 13;

	/**
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_CONNECTION_REJECTED_SECURITY_REASONS = 14;

	/**
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_REMOTE_USER_TERMINATED_CONNECTION_LOW_RESOURCES = 15;

	/**
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_REMOTE_USER_TERMINATED_CONNECTION_POWER_OFF = 16;

	/**
	 * Operation not applicable in this context.
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_NOT_APPLICABLE = 17;

	/**
	 * Service connection was rejected.
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_SERVICE_REJECTED = 18;

	/**
	 * Timeout on Service connection level.
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_SERVICE_CONNECT_TIMEOUT = 19;

	/**
	 * Action cannot be applied, because SIM is inserted
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.high
	 */
	public static final int RESULT_ERROR_SIM_INSERTED = 20;

	/**
	 * An additional phone cannot be connected while SAP is connected
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.high
	 */
	public static final int RESULT_ERROR_2ND_PHONE_NOT_POSSIBLE_WITH_SAP = 21;

	/**
	 * If Bluetooth connections are not possible due to an active CarPlay
	 * session
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_CARPLAY_ACTIVE = 22;

	/**
	 * If further Bluetooth connections or the requested profile(s) are not
	 * available due to an active Android Auto session
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_ANDROID_AUTO_ACTIVE = 23;

	/**
	 * If a characteristic notify event cannot be processed as no device is<BR>
	 * connected anymore
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_NO_DEVICE_SUBSCRIBED = 24;

	/**
	 * If a characteristic notify value was not received by the remote device
	 *
	 * @enum Result (results returned in response methods)
	 *
	 * @mib.common
	 */
	public static final int RESULT_ERROR_NOTIFY_TIMEOUT = 25;

	/**************************************************/
	/****************** LinkMode **********************/
	/**************************************************/

	/**
	 * Unspecified link mode.
	 *
	 * @enum LinkMode (eLinkMode describes the link state of the Bluetooth
	 *       device.)
	 * @mib.common
	 */
	public static final int LINKMODE_UNSPECIFIED = 0;

	/**
	 * Link state active.
	 *
	 * @enum LinkMode (eLinkMode describes the link state of the Bluetooth
	 *       device.)
	 * @mib.common
	 */
	public static final int LINKMODE_ACTIVE = 1;

	/**
	 * Link state hold.
	 *
	 * @enum LinkMode (eLinkMode describes the link state of the Bluetooth
	 *       device.)
	 * @mib.common
	 */
	public static final int LINKMODE_HOLD = 2;

	/**
	 * Link state sniff.
	 *
	 * @enum LinkMode (eLinkMode describes the link state of the Bluetooth
	 *       device.)
	 * @mib.common
	 */
	public static final int LINKMODE_SNIFF = 3;

	/**
	 * Link state park.
	 *
	 * @enum LinkMode (eLinkMode describes the link state of the Bluetooth
	 *       device.)
	 * @mib.common
	 */
	public static final int LINKMODE_PARK = 4;

	/**************************************************/
	/************** LinkkeyStrength *******************/
	/**************************************************/

	/**
	 * Not available.
	 *
	 * @enum LS (Link key strength of the trusted device)
	 * @mib.common
	 */
	public static final int LS_UNDEFINED = 0;

	/**
	 * Weak, e.g. HFP
	 *
	 * @enum LS (Link key strength of the trusted device)
	 * @mib.common
	 */
	public static final int LS_WEAK_KEY = 1;

	/**
	 * Strong, e.g. SAP
	 *
	 * @enum LS (Link key strength of the trusted device)
	 * @mib.common
	 */
	public static final int LS_STRONG_KEY = 2;

	/**
	 * �man in the middle protection� not ensured
	 *
	 * @enum LS (Link key strength of the trusted device)
	 * @mib.common
	 */
	public static final int LS_SIMPLE_PAIRING_UNAUTHENTICATED = 3;

	/**
	 * "man in the middle protection" ensured
	 *
	 * @enum LS (Link key strength of the trusted device)
	 * @mib.common
	 */
	public static final int LS_SIMPLE_PAIRING_AUTHENTICATED = 4;

	/**************************************************/
	/*************** PasskeyStates ********************/
	/**************************************************/

	/**
	 * no passkey is required (idle state)
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_NO_PASSKEY_REQUIRED = 0;

	/**
	 * passkey is required, the PIN must be entered on the MU
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_WAITING_FOR_PASSKEY = 1;

	/**
	 * passkey is required, the PIN must be shown on the MU and typed on the
	 * remote device
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_DISPLAY_PASSKEY = 2;

	/**
	 * An passkey related error occured.
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_PASSKEY_ERROR = 3;

	/**
	 * passkey procedure failed. The entered PINs did not match
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_PASSKEY_ERROR_WRONG_PIN = 4;

	/**
	 * passkey procedure failed. The allowed time for entering the PIN has
	 * elapsed
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_PASSKEY_ERROR_TIMEOUT = 5;

	/**
	 * Secure Simple Pairing procedure. The MU must show the given PIN
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_SSP_SHOW_ONLY = 6;

	/**
	 * Secure Simple Pairing procedure. The MU must show the given PIN and
	 * accept/reject the connection with requestPasskeyResponse
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_SSP_SHOW_AND_CONFIRM = 7;

	/**
	 * Secure Simple Pairing procedure. No PIN is given, the MU must only
	 * accept/reject the connection with requestPasskeyResponse
	 *
	 * @enum PS (Passkey states)
	 * @mib.common
	 */
	public static final int PS_SSP_JUST_WORKS = 8;

	/**************************************************/
	/***************** DeviceSecurity *****************/
	/**************************************************/

	/**
	 * Device is paired.
	 *
	 * @bitfield DeviceSecurity (Describes whether the Bluetooth device is
	 *           trusted, paired or unknown.)
	 * @mib.common
	 */
	public static final int DEVICESECURITY_PAIRED = 0x00;

	/**
	 * Device is trusted.
	 *
	 * @bitfield DeviceSecurity (Describes whether the Bluetooth device is
	 *           trusted, paired or unknown.)
	 * @mib.common
	 */
	public static final int DEVICESECURITY_TRUSTED = 0x02;

	/**
	 * Connection to device is encrypted.
	 *
	 * @bitfield DeviceSecurity (Describes whether the Bluetooth device is
	 *           trusted, paired or unknown.)
	 * @mib.common
	 */
	public static final int DEVICESECURITY_ENCRYPTED = 0x04;

	/**
	 * A strong pass key is used (>=16 digits).
	 *
	 * @bitfield DeviceSecurity (Describes whether the Bluetooth device is
	 *           trusted, paired or unknown.)
	 * @mib.common
	 */
	public static final int DEVICESECURITY_STRONG_PASSKEY = 0x08;

	/**************************************************/
	/********** DisconnectionInformation **************/
	/**************************************************/

	/**
	 * The device has been disconnected due to a different (potentially unknown)
	 * reason.
	 *
	 * @enum DisconnectInformation (Describes whether the disconnection was
	 *       initiated or the link got lost.)
	 * @mib.common
	 */
	public static final int DISCONNECTINFORMATION_OTHER_REASON = 0;

	/**
	 * The link to the device got lost, i.e. the disconnection was probably not
	 * initiated and not intended.
	 *
	 * @enum DisconnectInformation (Describes whether the disconnection was
	 *       initiated or the link got lost.)
	 * @mib.common
	 */
	public static final int DISCONNECTINFORMATION_LINK_LOSS = 1;

	/**
	 * The device disconnection was initiated via the external device, i.e. a
	 * disconnection request has been recieved.
	 *
	 * @enum DisconnectInformation (Describes whether the disconnection was
	 *       initiated or the link got lost.)
	 * @mib.common
	 */
	public static final int DISCONNECTINFORMATION_USER_INIT_VIA_EXT_DEVICE = 2;

	/**
	 * The device disconnection was initiated via the external device, i.e. a
	 * disconnection request has been recieved.
	 * <p>
	 * For Bluetooth LE.
	 *
	 * @enum DisconnectInformation (Describes whether the disconnection was
	 *       initiated or the link got lost.)
	 * @mib.common
	 */
	public static final int DISCONNECTINFORMATION_SYSTEM_INIT_IDLE_TIMEOUT = 3;

	/**************************************************/
	/************** ServiceRequestState ***************/
	/**************************************************/
	/**
	 * there is no active service request.
	 *
	 * @enum ServiceRequestState (Indicates whether a service connection is
	 *       requested or not.)
	 * @mib.common
	 */
	public static final int SERVICEREQUESTSTATE_NOT_ACTIVE = 0;

	/**
	 * there is an active service request.
	 *
	 * @enum ServiceRequestState (Indicates whether a service connection is
	 *       requested or not.)
	 * @mib.common
	 */
	public static final int SERVICEREQUESTSTATE_ACTIVE = 1;

	/**************************************************/
	/****************** ServiceType *******************/
	/**************************************************/

	/**
	 * Only used to indicate no active reconnection.
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_NONE = 0x00;

	/**
	 * Unspecified service
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_UNSPECIFIED = 0x01;

	/**
	 * HFP Audio Gateway
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_TELEPHONY_HFP = 0x02;

	/**
	 * SIMAP server
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_TELEPHONY_SIMAP = 0x04;

	/**
	 * HSP-HS
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_TELEPHONY_HEADSET = 0x08;

	/**
	 * BTHS device
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_TELEPHONY_HANDSET = 0x10;

	/**
	 * Abstract Addressbook download profile (abstracts PBAP, SYNCML, FBUS,
	 * etc.)
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_ADRDL = 0x20;

	/**
	 * OPP client
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_OBJECTPUSH_CLIENT = 0x40;

	/**
	 * SYNCML
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_SYNCML = 0x80;

	/**
	 * Dial-up Networking client
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_DUN_CLIENT = 0x100;

	/**
	 * Dial-up Networking server
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_DUN_SERVER = 0x200;

	/**
	 * Human Interface Design
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_HID = 0x400;

	/**
	 * Basic Imaging
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_BIP = 0x800;

	/**
	 * File Transfer Protocol
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_FTP = 0x1000;

	/**
	 * OPP Server
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_OBJECTPUSH_SERVER = 0x2000;

	/**
	 * Serial Port
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_SPP = 0x4000;

	/**
	 * Combination of A2DP sink and AVRCP controller (e.g. role of a BT headset
	 * in the RSE Use case or role of the MU controlling an external BT audio
	 * player).
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_A2DP_AVRCP_SINK = 0x8000;

	/**
	 * Combination of A2DP source and AVRCP target (e.g. role of an external
	 * audio player which is controlles by the MU).
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_A2DP_AVRCP_SOURCE = 0x10000;

	/**
	 * Hands Free Profile
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_TELEPHONY_HFP_HF = 0x20000;

	/**
	 * PAN Network Access Point
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_PAN_NAP = 0x40000;

	/**
	 * PAN Group Ad-hoc Network
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_PAN_GN = 0x80000;

	/**
	 * PAN User
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_PAN_USER = 0x100000;

	/**
	 * MAP Message Access Profile Version 1.0
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_MAP = 0x200000;

	/**
	 * MAP 2.0 Message Access Profile Version 2.0
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_MAP2 = 0x400000;

	/**
	 * All services
	 *
	 * @bitfield ServiceType (eServiceType indicates which high-level services
	 *           are offered by a Bluetooth device.)
	 * @mib.common
	 */
	public static final int SERVICETYPE_ALL = 0xffffffff;

	/**************************************************/
	/****************** ServiceID *********************/
	/**************************************************/

	/**
	 * Bluetooth low energy profile Device Information Service
	 *
	 * @bitfield ServiceID (eServiceID.)
	 * @mib.common
	 */
	public static final int SERVICEID_DIS = 0x00;

	/**
	 * Bluetooth low energy profile LNP
	 *
	 * @bitfield ServiceID (eServiceID.)
	 * @mib.common
	 */
	public static final int SERVICEID_LNP = 0x01;

	/**
	 * Bluetooth low energy profile HandOverService
	 *
	 * @bitfield ServiceID (eServiceID.)
	 * @mib.common
	 */
	public static final int SERVICEID_HOS = 0x02;

	/**
	 * Bluetooth low energy profile DTS
	 *
	 * @bitfield ServiceID (eServiceID.)
	 * @mib.common
	 */
	public static final int SERVICEID_DTS = 0x04;

	/**
	 * Bluetooth low energy profile HandOverService
	 *
	 * @bitfield ServiceID (eServiceID.)
	 * @mib.common
	 */
	public static final int SERVICEID_BEACON = 0x08;

	/**
	 * Bluetooth low energy profile com.volkswagen.service.01
	 *
	 * @bitfield ServiceID (eServiceID.)
	 * @mib.common
	 */
	public static final int SERVICEID_SERVICE_01 = 0x1000;

	/**************************************************/
	/****************** ServiceState ******************/
	/**************************************************/

	/**
	 * Bluetooth low energy profile is switched off
	 *
	 * @enum ServiceState (Describes the state of the local Bluetooth low energy
	 *       profile.)
	 * @mib.common
	 */
	public static final int SERVICESTATE_OFF = 0;

	/**
	 * Bluetooth low energy profile is temporally disabled.
	 *
	 * @enum ServiceState (Describes the state of the local Bluetooth low energy
	 *       profile.)
	 * @mib.common
	 */
	public static final int SERVICESTATE_TEMPORALLY_DISABLED = 1;

	/**
	 * Bluetooth low energy profile is activated and can be used by all devices.
	 *
	 * @enum ServiceState (Describes the state of the local Bluetooth low energy
	 *       profile.)
	 * @mib.common
	 */
	public static final int SERVICESTATE_ALL = 2;

	/**
	 * Bluetooth low energy profile is activated and can be used by trusted
	 * devices.
	 *
	 * @enum ServiceState (Describes the state of the local Bluetooth low energy
	 *       profile.)
	 * @mib.common
	 */
	public static final int SERVICESTATE_TRUSTED = 3;

	/**
	 * Bluetooth low energy profile is activated and can be used by devices with
	 * encription.
	 *
	 * @enum ServiceState (Describes the state of the local Bluetooth low energy
	 *       profile.)
	 * @mib.common
	 */
	public static final int SERVICESTATE_CRYPTED = 4;

	/**
	 * Bluetooth low energy profile is activated and can be used by trusted
	 * devices with encription.
	 *
	 * @enum ServiceState (Describes the state of the local Bluetooth low energy
	 *       profile.)
	 * @mib.common
	 */
	public static final int SERVICESTATE_TRUSTED_CRYPTED = 5;

}
