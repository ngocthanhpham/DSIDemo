/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */

package org.dsi.ifc.bluetooth;

import java.io.StringWriter;
import java.lang.StringBuffer;

/**
 * Represents a bluetooth device discovered during discovery.
 *
 *
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 * @mib.state APPROVED
 *
 *
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 *
 */
public class DiscoveredDevice {

	/**
	 * The Bluetooth device name of the discovered device.<br>
	 * Value Range: String
	 */
	public String deviceName;

	/**
	 * The Bluetooth device address of the discovered device.<br>
	 * Value Range: String
	 */
	public String deviceAddress;

	/**
	 * The 32bit Bluetooth device class describes the type of device. The
	 * definition of the single bits is according to the Bluetooth core protocol
	 * (Assigned Numbers).<br>
	 * Value Range: String
	 */
	public String deviceClass;

	/**
	 * List of available Bluetooth services.<br>
	 * Value range: Bitfield ServiceType (see
	 * {@link DSIBluetooth#SERVICETYPE_NONE} ff.)
	 */
	public int serviceTypes;

	/**
	 * The Received Signal Strength Indication<br>
	 * Value range: int, -128..127 (see Bt Core Spec 4.2, Sec. 7.5.4 Read RSSI
	 * Command)
	 */
	public int rssi;

	/**
	 * Default constructor without parameters.
	 */
	public DiscoveredDevice() {
		this.deviceName = null;
		this.deviceAddress = null;
		this.deviceClass = null;
		this.serviceTypes = 0;
		this.rssi = -128;
	}

	/**
	 * Constructor with parameters.
	 *
	 * @deprecated 21.03.2016;since DSI B2.78;for backward-compatibility
	 */
	public DiscoveredDevice(String deviceName, String deviceAddress,
			String deviceClass, int serviceTypes) {
		this.deviceName = deviceName;
		this.deviceAddress = deviceAddress;
		this.deviceClass = deviceClass;
		this.serviceTypes = serviceTypes;
		this.rssi = -128;
	}

	/**
	 * Constructor with parameters.
	 */
	public DiscoveredDevice(String deviceName, String deviceAddress,
			String deviceClass, int serviceTypes, int rssi) {
		this.deviceName = deviceName;
		this.deviceAddress = deviceAddress;
		this.deviceClass = deviceClass;
		this.serviceTypes = serviceTypes;
		this.rssi = rssi;
	}

	/**
	 * Getter : The Bluetooth device name is a name for the device presented to
	 * the user. A NULL string means that the name is unspecified. max. 248
	 * characters, UTF-8 encoding.
	 *
	 * @return The Bluetooth device name is a name for the device presented to
	 *         the user. A NULL string means that the name is unspecified. max.
	 *         248 characters, UTF-8 encoding.
	 */
	public String getDeviceName() {
		return deviceName;
	}

	/**
	 * Getter : The Bluetooth device address represented in hex format.
	 *
	 * @return The Bluetooth device address represented in hex format.
	 */
	public String getDeviceAddress() {
		return deviceAddress;
	}

	/**
	 * Getter : The 32bit Bluetooth device calss describes the type of device.
	 * The definition of the single bits is according to the Bluetooth core
	 * protocol.
	 *
	 * @return The 32bit Bluetooth device calss describes the type of device.
	 *         The definition of the single bits is according to the Bluetooth
	 *         core protocol.
	 */
	public String getDeviceClass() {
		return deviceClass;
	}

	/**
	 * Getter : List of available Bluetooth services.
	 *
	 * @return List of available Bluetooth services.
	 */
	public int getServiceTypes() {
		return serviceTypes;
	}

	/**
	 * Getter : Received signal strength indication.
	 *
	 * @return Received signal strength indication.
	 */
	public int getRssi() {
		return rssi;
	}

	/**
	 * Convert data type to string for debugging purposes.
	 * @return {@link String} representation of this object with simple value output
	 */
	public String toString() {
		final StringBuffer buffer = new StringBuffer(350);
		buffer.append("DiscoveredDevice");
		buffer.append('(');
		buffer.append("deviceName");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.deviceName);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("deviceAddress");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.deviceAddress);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("deviceClass");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.deviceClass);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("serviceTypes");
		buffer.append('=');
		buffer.append(this.serviceTypes);
		buffer.append(',');
		buffer.append("rssi");
		buffer.append('=');
		buffer.append(this.rssi);
		buffer.append(')');
		return buffer.toString();
	}

}
