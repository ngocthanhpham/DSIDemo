/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */

package org.dsi.ifc.bluetooth;

import org.dsi.ifc.base.DSIListener;

/**
 * Device Service Interface for bluetooth low energy.
 *
 * @servicename BluetoothLE
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public interface DSIBluetoothLEListener extends DSIListener {

	/**
	 * Returns the result of sending a Bluetooth LE passkey.
	 *
	 * @param btDeviceAddress
	 *            the address of the bluetooth le device to which the response
	 *            has been sent.
	 * @param btDeviceName
	 *            the name of the bluetooth le device to which the response has
	 *            been sent.
	 * @param result
	 *            the result of the corresponding request.<br>
	 *            Value Range: Enumeration Result (see
	 *            {@link Constants#RESULT_OK} ff.)
	 *            <ul>
	 *            <li> {@link Constants#RESULT_OK}: Operation has been
	 *            successfull.</li>
	 *            <li> {@link Constants#RESULT_ABORTED}: The user has aborted the
	 *            authentication procedure
	 *            (btAuthenticationResponse=AUTHENTICATION_REJECT) or a
	 *            connection set-up (requestAbortConnectService) which triggered
	 *            the authentication procedure.</li>
	 *            <li> {@link Constants#RESULT_ERROR_PAGE_TIMEOUT}: The selected
	 *            device cannot be found in the BT environment (no page
	 *            response).</li>
	 *            <li> {@link Constants#RESULT_ERROR_PAIRING_WRONG_PASSKEY}:
	 *            There is a passkey mismatch between the system and the
	 *            external device.</li>
	 *            <li> {@link Constants#RESULT_ERROR_PAIRING_TIMEOUT}: The 30
	 *            seconds LMP timer expired during pairing.</li>
	 *            <li> {@link Constants#RESULT_ERROR_PAIRING_GENERAL}: An error,
	 *            which cannot be mapped to any other known pairing error,
	 *            occurred during pairing.</li>
	 *            <li> {@link Constants#RESULT_ERROR_BT_MASTER}: The connection
	 *            set-up has been terminated because the remote device did not
	 *            accept to be a slave in the network.</li>
	 *            <li> {@link Constants#RESULT_ERROR_HW_FAILURE}: BT-module does
	 *            not react.</li>
	 *            <li> {@link Constants#RESULT_ERROR_GENERAL}: An error occurred,
	 *            which cannot be properly mapped to any of the other errors.</li>
	 *            </ul>
	 *
	 * @type Response
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestPasskeyResponse(String, String, int)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void responsePasskeyResponse(String btDeviceAddress,
			String btDeviceName, int result);

	/**
	 * Returns the result of removing a Bluetooth LE device from the list of
	 * trusted devices.
	 *
	 * @param btDeviceAddress
	 *            the address of the bluetooth le device to be removed from the
	 *            list of trusted devices.<br>
	 *            Value Range: String
	 * @param btDeviceName
	 *            the name of the bluetooth le device to be removed from the
	 *            list of trusted devices.<br>
	 *            Value Range: String
	 * @param result
	 *            the result of the corresponding request.<br>
	 *            Value Range: Enumeration Result (see
	 *            {@link Constants#RESULT_OK} ff.)
	 *            <ul>
	 *            <li> {@link Constants#RESULT_OK}: Device was removed from
	 *            �trusted devices� successfully (link key has been deleted).</li>
	 *            <li> {@link Constants#RESULT_ERROR_DEVICE_NOT_TRUSTED}: The
	 *            requested device is not contained in the list of trusted
	 *            devices and therefore cannot be removed.</li>
	 *            <li> {@link Constants#RESULT_ERROR_GENERAL}: An error occurred,
	 *            which cannot be properly mapped to any of the other errors.</li>
	 *            </ul>
	 *
	 * @type Response
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestRemoveAuthentication(String)}
	 * @relatedfunc {@link DSIBluetoothLEListener#updateTrustedDevices(TrustedLEDevice[], int)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void responseRemoveAuthentication(String btDeviceAddress,
			String btDeviceName, String result);

	/**
	 * Returns the result of switching the bluetooth le state.
	 *
	 * @param result
	 *            the result of the corresponding request.<br>
	 *            Value Range: Enumeration Result (see
	 *            {@link Constants#RESULT_OK} ff.)
	 *            <ul>
	 *            <li> {@link Constants#RESULT_OK}: Operation was successful.</li>
	 *            <li> {@link Constants#RESULT_ERROR_HW_FAILURE}: BT-module does
	 *            not react.</li>
	 *            <li> {@link Constants#RESULT_ERROR_GENERAL}: An error occurred,
	 *            which cannot be properly mapped to any of the other errors.</li>
	 *            </ul>
	 *
	 * @type Response
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestSwitchBTState(int)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void responseSwitchBTState(int result);

	/**
	 * Informs about an update of the state of the local bluetooth le device.
	 *
	 * @param bTState
	 *            the changed bluetooth le state<br>
	 *            Value Range: Enumeration BTState (see
	 *            {@link DSIBluetooth#BTSTATE_ON} ff.)
	 *
	 * @param validFlag
	 *            indicates whether data is valid or not. Value Range:
	 *            Enumeration AttrValidFlag
	 *
	 * @type Update
	 *
	 * @attribute notify_onChange {@link DSIBluetoothLE#ATTR_BTSTATE}
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestSwitchBTState(int)}
	 *
	 * @requirement
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void updateBTState(int bTState, int validFlag);

	/**
	 * Reponse for {@link DSIBluetoothLE#setAccessibleMode(int)}. In case
	 * {@link DSIBluetoothLE#setAccessibleMode(int)} succeeded, the response
	 * will be called after
	 * {@link DSIBluetoothLEListener#updateAccessibleMode(int, int)}. If it
	 * failed, {@link DSIBluetoothLEListener#updateAccessibleMode(int, int)}
	 * will never be called, thus only the response will occur.
	 *
	 * @param result
	 *            The result of the corresponding request<br>
	 *            Value Range: Enumeration Result (see
	 *            {@link Constants#RESULT_OK ff.)
	 *            <ul>
	 *            <li> {@link Constants#RESULT_OK}: Operation was
	 *            successful.</li> <li>
	 *            {@link Constants#RESULT_ERROR_GENERAL}: An error occurred,
	 *            which cannot be properly mapped to any of the other errors.</li>
	 *            </ul>
	 *
	 * @type Response
	 *
	 * @relatedfunc {@link DSIBluetoothLE#setAccessibleMode(int)}
	 * @relatedfunc {@link DSIBluetoothLEListener#updateAccessibleMode(int, int)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void responseSetAccessibleMode(int result);

	/**
	 * Informs about an update of the AccessibleMode of the local bluetooth le
	 * device.
	 *
	 * @param accessibleMode
	 *            the accessible mode of the bluetooth device.<br>
	 *            Value Range: Enumeration AM (see
	 *            {@link Constants#AM_UNSPECIFIED} ff.)
	 * @param validFlag
	 *            indicates whether data is valid or not.<br>
	 *            Value Range: Enumeration AttrValidFlag
	 *
	 * @type Update
	 * @attribute notify_always {@link DSIBluetoothLE#ATTR_ACCESSIBLEMODE}
	 *
	 * @relatedfunc {@link DSIBluetoothLE#setAccessibleMode(int)}
	 * @relatedfunc {@link DSIBluetoothLEListener#updateAccessibleMode(int, int)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 *
	 * @reference
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void updateAccessibleMode(int result, int validFlag);

	/**
	 * Informs about an update of the passkey state.<br>
	 * Indicates that a new passkey is required or that a passkey needs to be
	 * displayed (see {@link Constants#PS_NO_PASSKEY_REQUIRED ff.}).<br>
	 * If a new passkey has to be displayed it also indicates the passkey
	 * itself.<br>
	 * Note, that the passkey itself has only to be evaluated if the property
	 * indicates that a new passkey shall be displayed,<br>
	 * i.e. if btPasskeyState is PS_DISPLAY_PASSKEY, PS_SSP_SHOW_AND_CONFIRM or
	 * PS_SSP_PASSKEY_SHOW_ONLY.
	 *
	 * @param passkeyState
	 *            the updated pass key state<br>
	 *            Value Range: {@link PasskeyStateStruct}
	 * @param validFlag
	 *            indicates whether data is valid or not. Value Range:
	 *            Enumeration AttrValidFlag
	 *
	 * @type Update
	 *
	 * @attribute notify_always {@link DSIBluetoothLE#ATTR_PASSKEYSTATE}
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestPasskeyResponse(String, String, int)}
	 *
	 * @requirement
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void updatePasskeyState(PasskeyStateStruct passkeyState,
			int validFlag);

	/**
	 * Informs about changes in the list of trusted le devices.<br>
	 * This attribute contains all paired le devices and information about
	 * supported services, currently connected services, link key strength etc.
	 *
	 * @param trustedLEDevices
	 *            the trusted devices<br>
	 *            Value Range: array of {@link TrustedLEDevice}
	 * @param validFlag
	 *            indicates whether data is valid or not. Value Range:
	 *            Enumeration AttrValidFlag
	 *
	 * @type Update
	 *
	 * @attribute notify_onChange {@link DSIBluetoothLE#ATTR_TRUSTEDDEVICES}
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestPasskeyResponse(String, String, int)}
	 *
	 * @requirement
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void updateTrustedDevices(TrustedLEDevice[] trustedleDevices,
			int validFlag);

	/**
	 * Informs about an update of the user friendly name of the local bluetooth
	 * device.<br>
	 *
	 * @param userFriendlyName
	 *            the new user friendly name of the local bluetooth device.<br>
	 *            Value Range: String
	 * @param validFlag
	 *            indicates whether data is valid or not. Value Range:
	 *            Enumeration AttrValidFlag
	 *
	 * @type Update
	 *
	 * @attribute notify_onChange {@link DSIBluetoothLE#ATTR_USERFRIENDLYNAME}
	 *
	 * @requirement
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void updateUserFriendlyName(String userFriendlyName, int validFlag);

	/**
	 * Indicates that a device has been disconnected and signals the reason
	 * (user initiated via external device or connection loss).<br>
	 *
	 *
	 * @param btDeviceAddress
	 *            the MAC address of the bluetooth device that has been
	 *            disconnected.<br>
	 *            Value Range: String
	 * @param btDeviceName
	 *            the name of the bluetooth device that has been disconnected.<br>
	 *            Value Range: String
	 * @param disconnectionInfo
	 *            the reason for device disconnection<br>
	 *            Value Range: Enumeration DisconnectInformation (see
	 *            {@link Constants#DISCONNECTINFORMATION_LINK_LOSS} ff.)
	 *
	 * @type Indication
	 *
	 * @relatedfunc
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 * @reference
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void deviceDisconnectionInfo(String btDeviceAddress,
			String btDeviceName, int disconnectionInfo);

	/**
	 * Returns the result of switching the state of the bluetooth le profile.
	 *
	 * @param result
	 *            the result of the corresponding request.<br>
	 *            Value Range: Enumeration Result (see
	 *            {@link Constants#RESULT_OK} ff.)
	 *            <ul>
	 *            <li> {@link Constants#RESULT_OK}: Operation was successful.</li>
	 *            <li> {@link Constants#RESULT_ERROR_GENERAL}: An error occurred,
	 *            which cannot be properly mapped to any of the other errors.</li>
	 *            </ul>
	 *
	 * @type Response
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestSetService(int, int)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void responseSetService(int result);

	/**
	 * Informs about an update of the state of the bluetooth le profile.
	 *
	 * @param bleService
	 *            Struct BleService<br>
	 *            Value Range: {@link BleService}
	 * @param validFlag
	 *            indicates whether data is valid or not.<br>
	 *            Value Range: Enumeration AttrValidFlag
	 *
	 * @type Update
	 *
	 * @attribute notify_onChange {@link DSIBluetoothLE#ATTR_SERVICE}
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestSetService(int, int)}
	 *
	 * @requirement
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void updateService(BleService bleService, int validFlag);

	/**
	 * Returns the result of switching the state of the bluetooth le
	 * characteristic.
	 *
	 * @param result
	 *            the result of the corresponding request.<br>
	 *            Value Range: Enumeration Result (see
	 *            {@link Constants#RESULT_OK} ff.)
	 *            <ul>
	 *            <li> {@link Constants#RESULT_OK}: Operation was successful.</li>
	 *            <li> {@link Constants#RESULT_ERROR_GENERAL}: An error occurred,
	 *            which cannot be properly mapped to any of the other errors.</li>
	 *            </ul>
	 *
	 * @type Response
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestSetCharacteristicState(String, int)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void responseSetCharacteristicState(int result);

	/**
	 * Returns the result of notify characteristic value to a connected BLE
	 * device.
	 *
	 * @param result
	 *            the result of the corresponding request.<br>
	 *            Value Range: Enumeration Result (see
	 *            {@link Constants#RESULT_OK} ff.)
	 *            <ul>
	 *            <li> {@link Constants#RESULT_OK}: Operation was successful.</li>
	 *            <li> {@link Constants#RESULT_ERROR_GENERAL}: An error occurred,
	 *            which cannot be properly mapped to any of the other errors.</li>
	 *            </ul>
	 *
	 * @type Response
	 *
	 * @relatedfunc {@link DSIBluetoothLE#requestNotifyCharacteristicValue(String, String)}
	 *
	 * @requirement {@link doors://}
	 *
	 * @pre no preconditions
	 * @post no postconditions
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 * @errorcase
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void responseNotifyCharacteristicValue(int result);

	/**
	 * Informs about an retrieval of a value writen to the characteristic with
	 * given UUID
	 *
	 * @param characteristicUUID
	 *            the 128-bit UUID of the Service Characteristic<br>
	 *            Value Range: {@link String}
	 * @param receivedValue
	 *            the data to be notified to the Central device<br>
	 *            Value Range: {@link String}
	 * @param validFlag
	 *            indicates whether data is valid or not.<br>
	 *            Value Range: Enumeration AttrValidFlag
	 *
	 * @type Update
	 * @attribute notify_onChange
	 *            {@link DSIBluetoothLE#ATTR_CHARACTERISTICVALUE}
	 *
	 * @requirement
	 *
	 * @timing no timings specified
	 *
	 * @msc none
	 *
	 *
	 * @mib.common
	 * @mib.state DOCUMENTED
	 */
	public void updateCharacteristicValue(String characteristicUUID,
			String receivedValue, int validFlag);

}
