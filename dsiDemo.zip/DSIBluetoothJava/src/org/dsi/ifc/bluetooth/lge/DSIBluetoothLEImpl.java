package org.dsi.ifc.bluetooth.lge;

import java.util.HashMap;
import java.util.List;

/**
 * @author swapan.pati@lge.com
 *
 */

import org.dsi.ifc.base.DSIListener;

import org.dsi.ifc.bluetooth.DSIBluetoothLE;
import org.dsi.ifc.bluetooth.DSIBluetoothLEListener;
import org.dsi.ifc.bluetooth.proto.DSIBluetoothLEMsg.*;

import com.lge.mib3oi.dsi.DSIProvider;
import com.lge.mib3oi.dsi.NotifyListenerTable;
import com.lge.mib3oi.dsi.DSIDomain;
import com.lge.mib3oi.dsi.DSIInterfaceId;

public class DSIBluetoothLEImpl implements DSIBluetoothLE{
	
	public DSIProvider dsi = DSIProvider.getDSIInstance();
	public static HashMap<Integer, List<DSIListener>> listenerTable = null;
	private NotifyListenerTable notifyListeners = null;
	
	
	public DSIBluetoothLEImpl(){
		listenerTable = new HashMap<Integer, List<DSIListener>>();
		notifyListeners = new NotifyListenerTable (listenerTable);
	}
	
	
	@Override
	public void setNotification(int[] attributes, DSIListener listener) {	
		if(listener instanceof DSIBluetoothLEListener){ 
			notifyListeners.setNotification(attributes, listener);
		}
	}

	@Override
	public void setNotification(int attribute, DSIListener listener) {
		if(listener instanceof DSIBluetoothLEListener){
			notifyListeners.setNotification(attribute, listener);
		}
	}
	
	@Override
	public void setNotification(DSIListener listener) {
		int attributes[] = {DSIBluetoothLE.ATTR_ACCESSIBLEMODE,
							DSIBluetoothLE.ATTR_BTSTATE,
							DSIBluetoothLE.ATTR_CHARACTERISTICVALUE,
							DSIBluetoothLE.ATTR_PASSKEYSTATE,
							DSIBluetoothLE.ATTR_SERVICE,
							DSIBluetoothLE.ATTR_TRUSTEDDEVICES,
							DSIBluetoothLE.ATTR_USERFRIENDLYNAME};
		
		if(listener instanceof DSIBluetoothLEListener) {
			notifyListeners.setNotification(attributes, listener);
		}
	}
		

	@Override
	public void clearNotification(int[] attributes, DSIListener listener) {
		if(listener instanceof DSIBluetoothLEListener){
			notifyListeners.clearNotification(attributes, listener);
		}
	}

	@Override
	public void clearNotification(int attribute, DSIListener listener) {
		
		if(listener instanceof DSIBluetoothLEListener){
			notifyListeners.clearNotification(attribute, listener);
		}
		
	}

	@Override
	public void clearNotification(DSIListener listener) {
		int attributes[] = {DSIBluetoothLE.ATTR_ACCESSIBLEMODE,
							DSIBluetoothLE.ATTR_BTSTATE,
							DSIBluetoothLE.ATTR_CHARACTERISTICVALUE,
							DSIBluetoothLE.ATTR_PASSKEYSTATE,
							DSIBluetoothLE.ATTR_SERVICE,
							DSIBluetoothLE.ATTR_TRUSTEDDEVICES,
							DSIBluetoothLE.ATTR_USERFRIENDLYNAME};
		
		if(listener instanceof DSIBluetoothLEListener){
			notifyListeners.clearNotification(attributes, listener);
			listenerTable.clear();
		}
	}

	@Override
	public void requestPasskeyResponse(String btPasskey,
			String btDeviceAddress, int btAuthenticationResponse) {

// Serialize the input data via proto buffer 
		requestPasskeyResponse.Builder data= requestPasskeyResponse.newBuilder();
		data.setBtPasskey(btPasskey);
		data.setBtDeviceAddress(btDeviceAddress);
		data.setBtAuthenticationResponse(btAuthenticationResponse);
		
		DSISendMessage.Builder pb  = DSISendMessage.newBuilder();
		pb.setDSIAPIID(DSIBluetoothLE.RT_REQUESTPASSKEYRESPONSE);
		pb.setRequestpasskeyresponse(data);

//Store the Serialized data(Message) into Message Queue		
		byte[]  msg = pb.build().toByteArray();
		
		dsi.postDSIProviderMsg(msg, DSIDomain.BLUETOOTH, DSIInterfaceId.DSIBluetoothLE);
	}

	@Override
	public void requestRemoveAuthentication(String btDeviceAddress) {
		
		requestRemoveAuthentication.Builder data = requestRemoveAuthentication.newBuilder();
		data.setBtDeviceAddress(btDeviceAddress);
		
		DSISendMessage.Builder pb  = DSISendMessage.newBuilder();
		pb.setDSIAPIID(DSIBluetoothLE.RT_REQUESTREMOVEAUTHENTICATION);
		pb.setRequestremoveauthentication(data);
		
		byte[]  msg = pb.build().toByteArray();
		
		dsi.postDSIProviderMsg(msg, DSIDomain.BLUETOOTH, DSIInterfaceId.DSIBluetoothLE);
	}

	@Override
	public void requestSwitchBTState(int btStateTarget) {
		requestSwitchBTState.Builder data =  requestSwitchBTState.newBuilder();
		data.setBtStateTarget(btStateTarget);
		
		DSISendMessage.Builder pb  = DSISendMessage.newBuilder();
		pb.setDSIAPIID(DSIBluetoothLE.RT_REQUESTSWITCHBTSTATE);
		pb.setRequestswitchbtstate(data);
		
		byte[]  msg = pb.build().toByteArray();
		
		dsi.postDSIProviderMsg(msg, DSIDomain.BLUETOOTH, DSIInterfaceId.DSIBluetoothLE);
	}

	@Override
	public void setAccessibleMode(int accessibleMode) {
		setAccessibleMode.Builder data = setAccessibleMode.newBuilder();
		data.setAccessibleMode(accessibleMode);
		
		DSISendMessage.Builder pb  = DSISendMessage.newBuilder();
		pb.setDSIAPIID(DSIBluetoothLE.RT_SETACCESSIBLEMODE);
		pb.setSetaccessiblemode(data);
		
		byte[]  msg = pb.build().toByteArray();
		
		dsi.postDSIProviderMsg(msg, DSIDomain.BLUETOOTH, DSIInterfaceId.DSIBluetoothLE);
	}

	@Override
	public void requestSetUserFriendlyName(String Name) {
		requestSetUserFriendlyName.Builder data = requestSetUserFriendlyName.newBuilder();
		data.setName(Name);
		
		DSISendMessage.Builder pb  = DSISendMessage.newBuilder();
		pb.setDSIAPIID(DSIBluetoothLE.RT_REQUESTSETUSERFRIENDLYNAME);
		pb.setRequestsetuserfriendlyname(data);
		
		byte[]  msg = pb.build().toByteArray();
		
		dsi.postDSIProviderMsg(msg, DSIDomain.BLUETOOTH, DSIInterfaceId.DSIBluetoothLE);
	}

	@Override
	public void requestSetService(int ServiceID, int ServiceState) {
		requestSetService.Builder data= requestSetService.newBuilder();
		data.setServiceID(ServiceID);
		data.setServiceState(ServiceState);
		
		DSISendMessage.Builder pb  = DSISendMessage.newBuilder();
		pb.setDSIAPIID(DSIBluetoothLE.RT_REQUESTSETSERVICE);
		pb.setRequestsetservice(data);
		
		byte[]  msg = pb.build().toByteArray();
		
		dsi.postDSIProviderMsg(msg, DSIDomain.BLUETOOTH, DSIInterfaceId.DSIBluetoothLE);
	}

	@Override
	public void requestSetCharacteristicState(String uuid, int serviceState) {
		requestSetCharacteristicState.Builder data = requestSetCharacteristicState.newBuilder();
		data.setUuid(uuid);
		data.setServiceState(serviceState);
		
		DSISendMessage.Builder pb  = DSISendMessage.newBuilder();
		pb.setDSIAPIID(DSIBluetoothLE.RT_REQUESTSETCHARACTERISTICSTATE);
		pb.setRequestSetcharacteristicState(data);
		
		byte[]  msg = pb.build().toByteArray();
		
		dsi.postDSIProviderMsg(msg, DSIDomain.BLUETOOTH, DSIInterfaceId.DSIBluetoothLE);
	}

	@Override
	public void requestNotifyCharacteristicValue(String characteristicUUID,
			String notifyValue) {
		requestNotifyCharacteristicValue.Builder data = requestNotifyCharacteristicValue.newBuilder();
		data.setCharacteristicUUID(characteristicUUID);
		data.setNotifyValue(notifyValue);
		
		DSISendMessage.Builder pb  = DSISendMessage.newBuilder();
		pb.setDSIAPIID(DSIBluetoothLE.RT_REQUESTNOTIFYCHARACTERISTICVALUE);
		pb.setRequestnotifycharacteristicvalue(data);
		
		byte[]  msg = pb.build().toByteArray();
		
		dsi.postDSIProviderMsg(msg, DSIDomain.BLUETOOTH, DSIInterfaceId.DSIBluetoothLE);
	}
	
}
