/**
 * File created by Swapan (swapan.pati@lge.com)
 */
package org.dsi.ifc.bluetooth.lge;

import java.util.LinkedList;
import java.util.List;

import org.dsi.ifc.base.DSIListener;
import org.dsi.ifc.bluetooth.DSIBluetoothLE;
import org.dsi.ifc.bluetooth.DSIBluetoothLEListener;
import org.dsi.ifc.bluetooth.proto.DSIBluetoothLEListenerMsg.*;
import com.google.protobuf.InvalidProtocolBufferException;

import com.lge.mib3oi.dsi.Message;
import com.vw.mib3oi.DSIBluetoothLEListenerImpl;

/**
 * @author swapan.pati
 *
 */

public class DSIBluetoothLEListenerService  {
	
	DSIListenerSendMessage pb = null;
	DSIBluetoothLEListener listener = new DSIBluetoothLEListenerImpl();
	Message ResponseMsg;
	
	public DSIBluetoothLEListenerService(Message msg){
		this.ResponseMsg = msg;
	}

	
	public List<DSIListener> GetLisenerList(int attribute){
		List<DSIListener> listenerList = new LinkedList<DSIListener>();
		if (DSIBluetoothLEImpl.listenerTable.containsKey(attribute)){
			listenerList = DSIBluetoothLEImpl.listenerTable.get(attribute);
		}
		else{
			listenerList = null;
		}
		return listenerList;
	}

public void executeListenerService(){
	
try{	
	pb = DSIListenerSendMessage.parseFrom(ResponseMsg.getData());
	switch(pb.getDSIAPIID()){
	  case DSIBluetoothLE.RP_RESPONSENOTIFYCHARACTERISTICVALUE:
	  {
		  responseNotifyCharacteristicValue data = pb.getResponseNotifyCharacteristicValue();
		  listener.responseNotifyCharacteristicValue(data.getResult());
	  }
		  break;
		  
	  case DSIBluetoothLE.RP_RESPONSEPASSKEYRESPONSE:
	  {
		  responsePasskeyResponse data = pb.getResponsePasskeyResponse();
		  listener.responsePasskeyResponse(data.getBtDeviceAddress(), data.getBtDeviceName(), data.getResult());
	  }
		  break;
	  case DSIBluetoothLE.RP_RESPONSEREMOVEAUTHENTICATION:
	  {
		  responseRemoveAuthentication data = pb.getResponseRemoveAuthentication();
		  listener.responseRemoveAuthentication(data.getBtDeviceAddress(), data.getBtDeviceName(), data.getResult());
	  }
		  break;
	  case DSIBluetoothLE.RP_RESPONSESETACCESSIBLEMODE:
	  {
		  responseSetAccessibleMode data = pb.getResponseSetAccessibleMode();
		  listener.responseSetAccessibleMode(data.getResult());
	  }
		  break;
	  case DSIBluetoothLE.RP_RESPONSESETCHARACTERISTICSTATE:
	  {
		  responseSetCharacteristicState data = pb.getResponseSetCharacteristicState();
		  listener.responseSetCharacteristicState(data.getResult());
	  }
		  break;
	  case DSIBluetoothLE.RP_RESPONSESETSERVICE:
	  {
		  responseSetService data = pb.getResponseSetService();
		  listener.responseSetService(data.getResult());
	  }
		  break;
	  case DSIBluetoothLE.RP_RESPONSESWITCHBTSTATE:
	  {
		  responseSwitchBTState data = pb.getResponseSwitchBTState();
		  listener.responseSwitchBTState(data.getResult());
	  }
		  break;
	  case DSIBluetoothLE.ATTR_BTSTATE:
	  {
		  updateBTState data = pb.getUpdateBTState();
		  List<DSIListener> listenerList = GetLisenerList(DSIBluetoothLE.ATTR_BTSTATE);
		  if ((listenerList != null) && (listenerList.size() > 0)){
			  for(int i = 0; i<listenerList.size(); i++){
				  DSIBluetoothLEListener obj = (DSIBluetoothLEListener)listenerList.get(i);
				  if(obj != null) obj.updateBTState(data.getBTState(), data.getValidFlag());
			  }
		  }
	  }
	  	 break;
	  case DSIBluetoothLE.ATTR_ACCESSIBLEMODE:
		  break;
	  case DSIBluetoothLE.ATTR_CHARACTERISTICVALUE:
		  break;
	  case DSIBluetoothLE.ATTR_PASSKEYSTATE:
		  break;
	  case DSIBluetoothLE.ATTR_SERVICE:
		 break;
	  case DSIBluetoothLE.ATTR_TRUSTEDDEVICES:
		 break;
	  case DSIBluetoothLE.ATTR_USERFRIENDLYNAME:
		 break;
	  case DSIBluetoothLE.IN_DEVICEDISCONNECTIONINFO:
		 break; 
	  default:
		  break;
	  }
	
 } catch (InvalidProtocolBufferException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	
}

}
