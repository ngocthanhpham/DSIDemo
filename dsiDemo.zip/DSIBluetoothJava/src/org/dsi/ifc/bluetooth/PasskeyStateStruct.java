/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */

package org.dsi.ifc.bluetooth;

import java.io.StringWriter;
import java.lang.StringBuffer;

/**
 * Represents the passkey state of a bluetooth device.
 *
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 * @mib.state APPROVED
 *
 *
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 *
 */
public class PasskeyStateStruct {

	/**
	 * The Bluetooth pass key state<br>
	 * Value range: Enumeration PS (see
	 * {@link DSIBluetooth#PS_NO_PASSKEY_REQUIRED} ff.)
	 */
	public int btPasskeyState;

	/**
	 * The user friendly name of the trusted Bluetooth device.<br>
	 * Value Range: String
	 */
	public String btDeviceName;

	/**
	 * The Bluetooth device address represented in hex format.<br>
	 * Value Range: String
	 */
	public String btDeviceAddress;

	/**
	 * the corresponding pass key<br>
	 * Value Range: String
	 */
	public String btPasskey;

	/**
	 * Default constructor without parameters.
	 */
	public PasskeyStateStruct() {
		this.btPasskeyState = 0;
		this.btDeviceAddress = null;
		this.btDeviceName = null;
		this.btPasskey = null;
	}

	/**
	 * Constructor with parameters.
	 */
	public PasskeyStateStruct(int btPasskeyState, String btDeviceName,
			String btDeviceAddress, String btPasskey) {
		this.btPasskeyState = btPasskeyState;
		this.btDeviceName = btDeviceName;
		this.btDeviceAddress = btDeviceAddress;
		this.btPasskey = btPasskey;
	}

	/**
	 * Getter : btPasskeyState
	 *
	 * @return btPasskeyState
	 */
	public int getBtPasskeyState() {
		return btPasskeyState;
	}

	/**
	 * Getter : btDeviceAddress
	 *
	 * @return btDeviceAddress
	 */
	public String getBtDeviceAddress() {
		return btDeviceAddress;
	}

	/**
	 * Getter : btDeviceName
	 *
	 * @return btDeviceName
	 */
	public String getBtDeviceName() {
		return btDeviceName;
	}

	/**
	 * Getter : btPasskey
	 *
	 * @return btPasskey
	 */
	public String getBtPasskey() {
		return btPasskey;
	}

	/**
	 * Convert data type to string for debugging purposes.
	 * @return {@link String} representation of this object with simple value output
	 */
	public String toString() {
		final StringBuffer buffer = new StringBuffer(350);
		buffer.append("PasskeyStateStruct");
		buffer.append('(');
		buffer.append("btPasskeyState");
		buffer.append('=');
		buffer.append(this.btPasskeyState);
		buffer.append(',');
		buffer.append("btDeviceName");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btDeviceName);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("btDeviceAddress");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btDeviceAddress);
		buffer.append('\"');
		buffer.append(',');
		buffer.append("btPasskey");
		buffer.append('=');
		buffer.append('\"');
		buffer.append(this.btPasskey);
		buffer.append('\"');
		buffer.append(')');
		return buffer.toString();
	}

}
