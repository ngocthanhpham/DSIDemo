/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.bluetooth;

import java.lang.StringBuffer;

/**
 * Represents a bluetooth low energy service.
 *
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 *
 * @mib.common
 * @mib.state DOCUMENTED
 * @dsi.build.date 28.10.2016 16:57
 * @dsi.specification.name MIB_DSI_2016_KW44
 * @dsi.specification.version 16.44.0
 * @dsi.specification.nickname B2.86
 */
public class BleService {

	/**
	 * The ID of the bluetooth low energy service.<br>
	 * Value Range: Bitfield ServiceID (see {@link DSIBluetoothLE#SERVICEID_DIS}
	 * ff.)
	 */
	public int serviceID;

	/**
	 * The state of the bluetooth low energy service..<br>
	 * Value Range: Enumeration ServiceState (see
	 * {@link DSIBluetoothLE#SERVICESTATE_OFF} ff.)
	 */
	public int serviceState;

	/**
	 * Default constructor without parameters.
	 */
	public BleService() {
		this.serviceID = 0;
		this.serviceState = 0;
	}

	/**
	 * @param serviceID
	 * @param serviceState
	 */
	public BleService(int serviceID, int serviceState) {
		this.serviceID = serviceID;
		this.serviceState = serviceState;
	}

	/**
	 * @return the ServiceID
	 */
	public int getServiceID() {
		return serviceID;
	}

	/**
	 * @return the ServiceState
	 */
	public int getServiceState() {
		return serviceState;
	}

	/**
	 * Convert data type to string for debugging purposes.
	 * @return {@link String} representation of this object with simple value output
	 */
	public String toString() {
		final StringBuffer buffer = new StringBuffer(150);
		buffer.append("BleService");
		buffer.append('(');
		buffer.append("serviceID");
		buffer.append('=');
		buffer.append(this.serviceID);
		buffer.append(',');
		buffer.append("serviceState");
		buffer.append('=');
		buffer.append(this.serviceState);
		buffer.append(')');
		return buffer.toString();
	}

}
