/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.base;

/**
 * Specifies the commonly used error codes.
 * 
 * @servicename Base
 * 
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 * 
 * @mib.state APPROVED
 * @mib.common
 */
public interface DSIError {

	/*
	 * critical errors in DSI core from internal listener 80xx and 81xx
	 */

	public static final int ERROR_LISTENER_UPDATE_UNKNOWNFUNCTION = 8000;

	public static final int ERROR_LISTENER_RESPONSE_UNKNOWNFUNCTION = 8010;
	public static final int ERROR_LISTENER_RESPONSE_NONFATALEXCEPTION = 8011;
	public static final int ERROR_LISTENER_RESPONSE_FATALEXCEPTION = 8012;
	public static final int ERROR_LISTENER_RESPONSE_IOEXCEPTION = 8013;

	public static final int ERROR_LISTENER_UPDATE_CLASSCASTEXCEPTION = 8100;
	public static final int ERROR_LISTENER_RESPONSE_CLASSCASTEXCEPTION = 8101;
	public static final int ERROR_LISTENER_ADDLISTENER_CLASSCASTEXCEPTION = 8102;

	public static final int ERROR_DECODER_COMPILE = 8200;

	/**
	 * This error code informs the HMI that call of a request function has been
	 * rejected by the system application because it is currently locked due to
	 * its request modality specification.
	 * 
	 * @enum Error (Enumeration describing error codes for an asyncException
	 *       call)
	 */
	public static final int ERROR_REQUEST_BUSY = 8300;

	/**
	 * Error code to indicate that an invalid attribute (notification function
	 * id) has been passed to one of the setNotification()- or
	 * clearNotification() methods.
	 * 
	 * @enum Error (Enumeration describing error codes for an asyncException
	 *       call)
	 */
	public static final int ERROR_INVALID_ATTRIBUTE = 8301;

	/**
	 * Error code to indicate that an invalid argument has been passed to
	 * request method.
	 * 
	 * @enum Error (Enumeration describing error codes for an asyncException
	 *       call)
	 */
	public static final int ERROR_INVALID_ARGUMENT = 8302;

	/**
	 * Error code to indicate that the DSI service provider is not able to serve
	 * the current request.
	 * 
	 * @enum Error (Enumeration describing error codes for an asyncException
	 *       call)
	 */
	public static final int ERROR_INVALID_STATE = 8303;

	/**
	 * This error code informs that the call of a request function has been
	 * timed out.
	 * 
	 * @enum Error (Enumeration describing error codes for an asyncException
	 *       call)
	 */
	public static final int ERROR_REQUEST_TIMEOUT = 8304;

	/**
	 * This error code informs that a function has been called which is not
	 * supported for the current variant (e.g. an &#064;mib.high function on a
	 * standard system has been called or is not available at current use case).
	 * 
	 * @enum Error (Enumeration describing error codes for an asyncException
	 *       call)
	 */
	public static final int ERROR_FUNCTION_NOTSUPPORTED = 8305;

	/**
	 * Error code to indicate that the media entry id is out of date.
	 * 
	 * @enum Error (Enumeration describing error codes for an asyncException
	 *       call)
	 */
	public static final int ERROR_ENTRYID_NOT_FOUND = 10001;

	/**
	 * Error code to indicate that maximum entries are reached within media
	 * context, e.g. while adding items to an �On-The-Go� playlist via
	 * DSIMediaBrowser.
	 * 
	 * @enum Error (Enumeration describing error codes for an asyncException
	 *       call)
	 * 
	 */
	public static final int ERROR_MAX_ENTRIES = 10002;

}
