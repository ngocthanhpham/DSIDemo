/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.base;

/**
 * An adapter manager maintains a registry of adapter factories. Clients
 * directly invoke methods on an adapter manager to register and unregister
 * adapters.
 * <p>
 * The implementing class (provided by south side DSI part) must be registered
 * as service at the systems service registry (equal to where the DSI services
 * are registered, e.g. OSGi) with the following registration information:<br>
 * <ul>
 * <li>The registration name:<br>
 * <code>
 * String name=org.dsi.ifc.base.IAdapterManager</code></li>
 * <li>The instance of the class which implements this interface:<br>
 * <code>
 * service=new MyDSIAdapterManagerImplementation()</code></li>
 * <li>A property set specifying further information:<br>
 * (currently none specified)</li>
 * </ul>
 * 
 * @mib.state APPROVED
 * @mib.common
 */
public interface IAdapterManager {

	/**
	 * Registers the given adapter factory.
	 * 
	 * @param factory
	 *            the adapter factory
	 * 
	 * @see #unregisterFactories(IFactory)
	 */
	public void registerFactories(IFactory factory);

	/**
	 * Removes the given adapter factory completely from the list of registered
	 * factories.
	 * 
	 * @param factory
	 *            the adapter factory to remove
	 * @see #registerFactories(IFactory)
	 */
	public void unregisterFactories(IFactory factory);

	/**
	 * Returns an object which is an instance of the given class name. Return
	 * <code>null</code> if no such object can be found.
	 * 
	 * @param factoryType
	 *            the type of adapter to look up
	 * @return an object castable to the given adapter type, or
	 *         <code>null</code> if the given adaptable object does not have an
	 *         available adapter of the given type
	 */
	public Object getFactory(Class factoryType);

}
