/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.base;

/**
 * Base interface for all DSI provider.
 * 
 * @servicename Base
 */
public interface DSIBase {

	/**
	 * Property for registration of service.
	 */
	public static final String DEVICE_NAME = "DEVICE_NAME";

	/**
	 * Property for registration of service.
	 */
	public static final String DEVICE_INSTANCE = "DEVICE_INSTANCE";

	/**
	 * Adds the listener for notifications including the given attributes.
	 * 
	 * @param attributes
	 *            The list of attributes.
	 * @param listener
	 *            The listener itself.
	 * 
	 * @type Request function-parallel
	 * 
	 * @mib.state APPROVED
	 * @mib.common
	 */
	public void setNotification(int[] attributes, DSIListener listener);

	/**
	 * Adds the listener for notifications including the given attribute.
	 * 
	 * @param attribute
	 *            The attribute.
	 * @param listener
	 *            The listener itself.
	 * 
	 * @type Request function-parallel
	 * 
	 * @mib.state APPROVED
	 * @mib.common
	 */
	public void setNotification(int attribute, DSIListener listener);

	/**
	 * Adds the listener for notifications including all attributes of the
	 * provider.
	 * 
	 * @param listener
	 *            The listener itself.
	 * 
	 * @type Request function-parallel
	 * 
	 * @mib.state APPROVED
	 * @mib.common
	 */
	public void setNotification(DSIListener listener);

	/**
	 * Remove listener for notifications of the given attributes.
	 * 
	 * @param attributes
	 *            The list of attributes.
	 * @param listener
	 *            The listener to be removed.
	 * 
	 * @type Request function-parallel
	 * 
	 * @mib.state APPROVED
	 * @mib.common
	 */
	public void clearNotification(int[] attributes, DSIListener listener);

	/**
	 * Remove listener for notifications of the given attribute.
	 * 
	 * @param attribute
	 *            The list of attributes.
	 * @param listener
	 *            The listener to be removed.
	 * 
	 * @type Request function-parallel
	 * 
	 * @mib.state APPROVED
	 * @mib.common
	 */
	public void clearNotification(int attribute, DSIListener listener);

	/**
	 * Remove listener for all notifications of the provider.
	 * 
	 * @param listener
	 *            The listener to be removed.
	 * 
	 * @type Request function-parallel
	 * 
	 * @mib.state APPROVED
	 * @mib.common
	 */
	public void clearNotification(DSIListener listener);

}
