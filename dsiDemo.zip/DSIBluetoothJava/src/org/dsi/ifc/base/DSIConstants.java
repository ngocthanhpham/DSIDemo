/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.base;

/**
 * Specifies commonly used constants.
 * 
 * @servicename Base
 * 
 * @mib.state APPROVED
 * @mib.common
 */
public interface DSIConstants {

	/**
	 * This constant has to be used for all empty {@link String} within the DSI
	 * service definitions, e.g. in the default constructor of DSI data
	 * container classes as default value.
	 */
	public static final String EMPTY_STRING = "";

}
