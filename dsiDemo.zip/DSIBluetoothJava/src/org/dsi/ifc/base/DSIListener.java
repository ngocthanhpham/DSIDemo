/*
 * Copyright (c) Volkswagen AG. All Rights Reserved.
 */
package org.dsi.ifc.base;

/**
 * Base interface for all DSI listener.
 * 
 * @servicename Base
 * 
 * @serial Copyright (c) Volkswagen AG. All Rights Reserved.
 */
public interface DSIListener {

	/**
	 * Request function not defined.
	 */
	public static final int RT_NONE = 0;

	/**
	 * Valid flag UNKNOWN (used in update methods) - state of attribute is
	 * unknown.
	 * 
	 * @enum AttrValidFlag (Flag which informs about the validity of transmitted
	 *       data of a notification call)
	 */
	public static final int ATTRVALIDFLAG_UNKNOWN = 0;

	/**
	 * Valid flag VALID (used in update methods) - state of attribute is valid.
	 * 
	 * @enum AttrValidFlag (Flag which informs about the validity of transmitted
	 *       data of a notification call)
	 */
	public static final int ATTRVALIDFLAG_VALID = 1;

	/**
	 * Valid flag INVALID (used in update methods) - state of attribute is
	 * invalid.
	 * 
	 * @enum AttrValidFlag (Flag which informs about the validity of transmitted
	 *       data of a notification call)
	 */
	public static final int ATTRVALIDFLAG_INVALID = 2;

	/**
	 * Async exception for sending error information from a system component to
	 * the HMI.
	 * 
	 * @type Indication
	 * 
	 * @param errorCode
	 *            the error code, either on of the common error codes specified
	 *            by {@link DSIError} or a service specific error code
	 * @param errorMsg
	 *            error message which describes the error that has occurred
	 * @param requestType
	 *            request function ID RT_* of specific DSI service or RT_NONE,
	 *            if error does not correspond to a request
	 * 
	 * @mib.state APPROVED
	 * @mib.common
	 */
	public void asyncException(int errorCode, String errorMsg, int requestType);

}
