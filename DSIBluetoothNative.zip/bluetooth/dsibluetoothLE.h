#include <jni.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <string>
#include "proto\DSIBluetoothLE.pb.h"
#include "proto\DSIBluetoothLEListener.pb.h"

using namespace std;
using namespace proto;


class DSIBluetoothLE{
public:
/******************** Updates *********************/
	static const int ATTR_ACCESSIBLEMODE = 1;
	static const int ATTR_BTSTATE = 2;
	static const int ATTR_SERVICE = 3;
	static const int ATTR_TRUSTEDDEVICES = 4;
	static const int ATTR_PASSKEYSTATE = 5;
	static const int ATTR_USERFRIENDLYNAME = 6;
	static const int ATTR_CHARACTERISTICVALUE = 7;

/******************* Indications ******************/
	static const int IN_DEVICEDISCONNECTIONINFO = 3001;

/******************** Requests ********************/
	static const int RT_REQUESTPASSKEYRESPONSE = 1001;
	static const int RT_REQUESTREMOVEAUTHENTICATION = 1002;
	static const int RT_REQUESTSETUSERFRIENDLYNAME = 1003;
	static const int RT_REQUESTSWITCHBTSTATE = 1004;
	static const int RT_REQUESTSETSERVICE = 1005;
	static const int RT_SETACCESSIBLEMODE = 1006;
	static const int RT_REQUESTSETCHARACTERISTICSTATE = 1007;
	static const int RT_REQUESTNOTIFYCHARACTERISTICVALUE = 1008;

/******************** Responses *******************/
	static const int RP_RESPONSEPASSKEYRESPONSE = 2001;
	static const int RP_RESPONSEREMOVEAUTHENTICATION = 2002;
	static const int RP_RESPONSESWITCHBTSTATE = 2003;
	static const int RP_RESPONSESETSERVICE = 2004;
	static const int RP_RESPONSESETACCESSIBLEMODE = 2005;
	static const int RP_RESPONSESETCHARACTERISTICSTATE = 2006;
	static const int RP_RESPONSENOTIFYCHARACTERISTICVALUE = 2007;
};

class BluetoothDSI{
public:
	int DSIMsgProcess(char* data, int size, int interfaceId);
	void DSIResponseUpdate (DSIListenerSendMessage *pb);
};


class DSIBluetoothNative{
// Wherever Native method has mentioned that return type void*, those API are request<->response API
public:

	void requestPasskeyResponse(string btPasskey,string btDeviceAddress, int btAuthenticationResponse);
	void requestRemoveAuthentication(string btDeviceAddress);
	void requestSwitchBTState(int btStateTarget);
	void setAccessibleMode(int accessibleMode);
	void requestSetUserFriendlyName(string Name); // No DSI Response for this API
	void requestSetService(int ServiceID, int ServiceState);
	void requestSetCharacteristicState(string uuid, int serviceState);
	void requestNotifyCharacteristicValue(string characteristicUUID, string notifyValue);

// Update/Notification API
//These methods will Call by Native Core API whenever there is a change on Global Structure

	void UpdateBTState(int bTState, int validFlagm);
	void UpdateAccessibleMode(int result, int validFlag);
	void UpdateUserFriendlyName(string userFriendlyName, int validFlag);
	void UpdateCharacteristicValue(string characteristicUUID,string receivedValue, int validFlag);
	//void updatePasskeyState(PasskeyStateStruct passkeyState, int validFlag);
	//void updateTrustedDevices(TrustedLEDevice[] trustedleDevices, int validFlag);
	//void updateService(BleService bleService, int validFlag);

//Indication API
	void deviceDisconnectionInfo(string btDeviceAddress, string btDeviceName, int disconnectionInfo);
};
