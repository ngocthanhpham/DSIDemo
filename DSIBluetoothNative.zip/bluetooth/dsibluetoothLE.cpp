#include "dsibluetoothLE.h"
#include "../dsi/DSIService.h"


int BluetoothDSI::DSIMsgProcess(char* data, int size, int interfaceId){
	int result = 0 ; // SUCCESS
	DSISendMessage DSI;
	DSIBluetoothNative dsinative ;

	try{
		     DSI.ParseFromArray(data,size);
		     fflush(stdout);
		     switch (DSI.dsiapiid()){
		         case DSIBluetoothLE::RT_REQUESTPASSKEYRESPONSE :
		         {
		        	 requestPasskeyResponse pb;
		        	 pb = DSI.requestpasskeyresponse();
		        	 dsinative.requestPasskeyResponse(pb.btpasskey(), pb.btdeviceaddress(),pb.btauthenticationresponse());
		         }
		         	 break;

		          case DSIBluetoothLE::RT_REQUESTREMOVEAUTHENTICATION :
		         {
		        	 requestRemoveAuthentication pb;
		        	 pb = DSI.requestremoveauthentication();
		        	 dsinative.requestRemoveAuthentication(pb.btdeviceaddress());
		         }
		        	 break;
		         case DSIBluetoothLE::RT_REQUESTSWITCHBTSTATE :
		         {
		        	 requestSwitchBTState pb;
		        	 pb = DSI.requestswitchbtstate();
		        	 dsinative.requestSwitchBTState(pb.btstatetarget());
		         }
		        	 break;
		         case DSIBluetoothLE::RT_SETACCESSIBLEMODE :
		         {
		        	 setAccessibleMode pb;
		        	 pb = DSI.setaccessiblemode();
		        	 dsinative.setAccessibleMode(pb.accessiblemode());
		         }
		        	 break;
		         case DSIBluetoothLE::RT_REQUESTSETUSERFRIENDLYNAME :
		         {
		        	 requestSetUserFriendlyName pb;
		        	 pb = DSI.requestsetuserfriendlyname();
		        	 dsinative.requestSetUserFriendlyName(pb.name());
		         }
		        	 break;
		         case DSIBluetoothLE::RT_REQUESTSETSERVICE :
		         {
		        	 requestSetService pb;
		        	 pb = DSI.requestsetservice();
		        	 dsinative.requestSetService(pb.serviceid(), pb.servicestate());
		         }
		        	 break;
		         case DSIBluetoothLE::RT_REQUESTSETCHARACTERISTICSTATE :
		         {
		        	 requestSetCharacteristicState pb;
		        	 pb = DSI.requestsetcharacteristicstate();
		        	 dsinative.requestSetCharacteristicState(pb.uuid(), pb.servicestate());
		         }
		        	 break;
		         case DSIBluetoothLE::RT_REQUESTNOTIFYCHARACTERISTICVALUE :
		         {
		        	 requestNotifyCharacteristicValue pb;
		        	 pb = DSI.requestnotifycharacteristicvalue();
		        	 dsinative.requestNotifyCharacteristicValue(pb.characteristicuuid(), pb.notifyvalue());

		         }
		         break;

		         default:
		        	 result = DSIError::ERROR_INVALID_ARGUMENT; // WRONG DSIAPIID
		         break;
		        }

		 }catch(...){
			 result = DSIError::ERROR_INVALID_ARGUMENT;
		 }

    return result;

}

void BluetoothDSI::DSIResponseUpdate (DSIListenerSendMessage *pb){
	DSIService DSI;
	int size = pb->ByteSize();

	void* buffer = malloc(size);
	pb->SerializeToArray(buffer, size);

	DSI.sendDSIResponseUpdate (buffer, size, DSIDomain::BLUETOOTH, DSIInterfaceId::DSIBluetoothLEListener);
	free(buffer);
}



void DSIBluetoothNative::requestPasskeyResponse(string btPasskey,string btDeviceAddress, int btAuthenticationResponse) {
		// Native Core Operation
		cout << "requestPasskeyResponse DSI Provider Call at Native --> " << btPasskey <<" " <<btDeviceAddress << " " << btAuthenticationResponse <<"\n";
		fflush(stdout);

// Response
//void responsePasskeyResponse(java.lang.String btDeviceAddress,java.lang.String btDeviceName,int result)
		responsePasskeyResponse *data = new responsePasskeyResponse();
		data->set_btdeviceaddress("10:20:30:40");
		data->set_btdevicename("V20");
		data->set_result(100);

		DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		pb->set_dsiapiid(DSIBluetoothLE::RP_RESPONSEPASSKEYRESPONSE);
		pb->set_allocated_responsepasskeyresponse(data);


		BluetoothDSI DSI;
		DSI.DSIResponseUpdate(pb);

		pb->release_responsepasskeyresponse();
		delete(data);
		delete(pb);
	}



	 void DSIBluetoothNative::requestRemoveAuthentication(string btDeviceAddress) {
		 // Native Core Operation
		 cout << "requestRemoveAuthentication DSI Provider Call at Native --> " <<  btDeviceAddress << "\n";
		 fflush(stdout);
// Response
//	 void responseRemoveAuthentication(java.lang.String btDeviceAddress, java.lang.String btDeviceName,java.lang.String result)
		 responseRemoveAuthentication *data = new responseRemoveAuthentication();
		 data->set_btdeviceaddress("10:20:30:40");
		 data->set_btdevicename("V20");
		 data->set_result("SUCCESS");

		 DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		 pb->set_dsiapiid(DSIBluetoothLE::RP_RESPONSEREMOVEAUTHENTICATION);
		 pb->set_allocated_responseremoveauthentication(data);

		 BluetoothDSI DSI;
		 DSI.DSIResponseUpdate(pb);

		 pb->release_responseremoveauthentication();
		 delete(data);
		 delete(pb);
	 }

	 void DSIBluetoothNative::requestSwitchBTState(int btStateTarget) {
		 // Native Core Operation
		 cout << "requestSwitchBTState DSI Provider Call at Native --> " <<  btStateTarget << "\n";
		 fflush(stdout);
//Resposne
//void responseSwitchBTState(int result)
		 responseSwitchBTState *data = new responseSwitchBTState();
		 data->set_result(100);

		 DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		 pb->set_dsiapiid(DSIBluetoothLE::RP_RESPONSESWITCHBTSTATE);
		 pb->set_allocated_responseswitchbtstate(data);

		 BluetoothDSI DSI;
		 DSI.DSIResponseUpdate(pb);

		 pb->release_responseswitchbtstate();
		 delete(data);
		 delete(pb);
	 }

	 void DSIBluetoothNative::setAccessibleMode(int accessibleMode) {
		 // Native Core Operation
		 cout << "setAccessibleMode DSI Provider Call at Native --> " <<  accessibleMode << "\n";
		 fflush(stdout);
//Response
//void responseSetAccessibleMode(int result)
		 responseSetAccessibleMode *data = new responseSetAccessibleMode();
		 data->set_result(200);

		 DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		 pb->set_dsiapiid(DSIBluetoothLE::RP_RESPONSESETACCESSIBLEMODE);
		 pb->set_allocated_responsesetaccessiblemode(data);

		 BluetoothDSI DSI;
		 DSI.DSIResponseUpdate(pb);

		 pb->release_responsesetaccessiblemode();
		 delete(data);
		 delete(pb);
	}

	 void DSIBluetoothNative::requestSetUserFriendlyName(string Name) {
		 // Native Core Operation
		 cout << "requestSetUserFriendlyName DSI Provider Call at Native --> " <<  Name << "\n";
		 fflush(stdout);
	}

	 void DSIBluetoothNative::requestSetService(int ServiceID, int ServiceState) {
		 // Native Core Operation
		 cout << "requestSetService DSI Provider Call at Native --> " <<  ServiceID << " " << ServiceState << "\n";
		 fflush(stdout);
//Response
//void responseSetService(int result)
		 responseSetService *data = new responseSetService();
		 data->set_result(200);

		 DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		 pb->set_dsiapiid(DSIBluetoothLE::RP_RESPONSESETSERVICE);
		 pb->set_allocated_responsesetservice(data);

		 BluetoothDSI DSI;
		 DSI.DSIResponseUpdate(pb);

		 pb->release_responsesetservice();
		 delete(data);
		 delete(pb);

	 }

	 void DSIBluetoothNative::requestSetCharacteristicState(string uuid, int serviceState) {
		 // Native Core Operation
		 cout << "requestSetCharacteristicState DSI Provider Call at Native --> " <<  uuid << " " << serviceState << "\n";
		 fflush(stdout);

//Response
//void responseSetCharacteristicState(int result)
		 responseSetCharacteristicState *data = new responseSetCharacteristicState();
		 data->set_result(200);
		 DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		 pb->set_dsiapiid(DSIBluetoothLE::RP_RESPONSESETCHARACTERISTICSTATE);
		 pb->set_allocated_responsesetcharacteristicstate(data);

		 BluetoothDSI DSI;
		 DSI.DSIResponseUpdate(pb);

		 pb->release_responsesetcharacteristicstate();
		 delete(data);
		 delete(pb);
	}

	 void DSIBluetoothNative::requestNotifyCharacteristicValue(string characteristicUUID,
			string notifyValue) {
		//Native Core Operation
		cout << "requestNotifyCharacteristicValue DSI Provider Call at Native --> " <<  characteristicUUID << " " << notifyValue << "\n";
		fflush(stdout);

//  This DSI API Corresponding Response API..
//void responseNotifyCharacteristicValue(int result)
		int result = 100;
		responseNotifyCharacteristicValue *data = new responseNotifyCharacteristicValue();
		data->set_result(result);
		DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		pb->set_dsiapiid(DSIBluetoothLE::RP_RESPONSENOTIFYCHARACTERISTICVALUE);
		pb->set_allocated_responsenotifycharacteristicvalue(data);

		BluetoothDSI DSI;
		DSI.DSIResponseUpdate(pb);

		 pb->release_responsenotifycharacteristicvalue();
		 delete(data);
		 delete(pb);
	}


	 void DSIBluetoothNative::UpdateBTState(int bTState, int validFlag)
	 {

		updateBTState *data = new updateBTState();
		data->set_btstate(bTState);
		data->set_validflag(validFlag);

		DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		pb->set_dsiapiid(DSIBluetoothLE::ATTR_BTSTATE);
		pb->set_allocated_updatebtstate(data);

		BluetoothDSI DSI;
		DSI.DSIResponseUpdate(pb);

		pb->release_updatebtstate();
		delete(data);
		delete(pb);
	 }

	 void DSIBluetoothNative::UpdateAccessibleMode(int result, int validFlag){
		 updateAccessibleMode *data = new updateAccessibleMode();
		 data->set_result(result);
		 data->set_validflag(validFlag);

		 DSIListenerSendMessage *pb = new DSIListenerSendMessage();
		 pb->set_dsiapiid(DSIBluetoothLE::ATTR_ACCESSIBLEMODE);
		 pb->set_allocated_updateaccessiblemode(data);

		 BluetoothDSI DSI;
		 DSI.DSIResponseUpdate(pb);

		 pb->release_updateaccessiblemode();
		 delete(data);
		 delete(pb);

	 }





