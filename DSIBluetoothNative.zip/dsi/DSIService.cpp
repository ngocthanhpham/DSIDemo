#include "DSIService.h"
#include "..\bluetooth\dsibluetoothLE.h"


static JNIEnv *JavaEnv = NULL;
static jclass dsiClass = NULL;
static jmethodID dsiResponseMethod = NULL;
const char* dsiClassPath="com/lge/mib3oi/dsi/Handler";
const char* dsiResponseMethodName="sendResponseMessage";



JNIEXPORT void JNICALL Java_com_lge_mib3oi_dsi_Handler_initDsiNative
  (JNIEnv *env, jobject object){

	if (JavaEnv == NULL){
		JavaEnv = env;
	}
	if (dsiClass == NULL){
		dsiClass = JavaEnv->FindClass(dsiClassPath);
	}
	if (dsiResponseMethod == NULL){
		dsiResponseMethod = JavaEnv->GetStaticMethodID(dsiClass, dsiResponseMethodName, "([BII)V");
	}

}

JNIEXPORT jint JNICALL Java_com_lge_mib3oi_dsi_Handler_sendMessage
  (JNIEnv *env, jobject object, jbyteArray buffer, jint domainId, jint interfaceId){

	int result = 0; // SUCCESS

	JavaEnv = env;

	int len = env->GetArrayLength(buffer);
    if (len <= 0)return DSIError::ERROR_INVALID_ARGUMENT;

    jbyte *dsiMessage = env->GetByteArrayElements(buffer, 0);

	switch (domainId){
		case DSIDomain::BLUETOOTH: // Bluetooth Domain
		{
			BluetoothDSI dsi;
			result = dsi.DSIMsgProcess((char*)dsiMessage, len,interfaceId);
		}
		break;
		case DSIDomain::MEDIA: // Media Domain
		break;
		case DSIDomain::DISPLAYMANAGER: //DisplayManager Domain
		break;
		default:
		break;
	}

	env->ReleaseByteArrayElements(buffer, dsiMessage, JNI_ABORT);
	return result;
}


void DSIService::sendDSIResponseUpdate(void* data, int msgSize, int domainId, int interfaceId){

		dsiClass = JavaEnv->FindClass(dsiClassPath);
		dsiResponseMethod = JavaEnv->GetStaticMethodID(dsiClass, dsiResponseMethodName, "([BII)V");

	 	if (JavaEnv != NULL){
	 		jbyteArray responseMsg;
	 		responseMsg = JavaEnv->NewByteArray(msgSize);
	 		JavaEnv->SetByteArrayRegion(responseMsg, 0, msgSize, (jbyte*)data);
	 		JavaEnv->CallStaticVoidMethod(dsiClass, dsiResponseMethod, responseMsg, domainId, interfaceId);
	 	}
}







