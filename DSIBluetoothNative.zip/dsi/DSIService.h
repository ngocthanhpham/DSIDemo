#include <jni.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <string>
#include "DSI_JNI.h"
#include "DSIDomain.h"
#include "DSIInterfaceId.h"
#include "DSIError.h"

using namespace std;

class DSIService {
public:
	void sendDSIResponseUpdate(void* responseMsg, int msgSize, int domainId, int interfaceId);
};
